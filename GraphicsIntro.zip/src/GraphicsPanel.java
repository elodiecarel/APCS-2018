/**
 * Created by student on 9/25/17.
 */
import javax.swing.*;
import java.awt.*;

    public class GraphicsPanel extends JPanel{

        public GraphicsPanel(int width, int height){
            setSize(width,height);

        }
        // top left corner is origin, down and right are bigger.

        public void paintComponent(Graphics g){
            Graphics2D g2 = (Graphics2D)g;

//            g2.setColor(new Color(3, 245, 255));
//            g2.fillOval(0, 0,getWidth(), getHeight());
//                // rgb color system
//            g2.setColor(new Color(166, 19,255));
//
//                // g2 is the pen
//                // x, y, width, height
//            g2.fillRect(getWidth()/2-100,getHeight()/2-150, 200, 300);
//
//            g2.setStroke(new BasicStroke(10));
//            int[] xs = {getWidth()/2, getWidth(), 0};
//            int[] ys = {0, getHeight(), getHeight()};
//            g2.drawPolygon(xs, ys, 3);
//
//            // any font in computer "font book" //
//            g2.setColor(Color.black);
//            g2.setFont(new Font("Comic Sans MS" , Font.BOLD, 40));
//            g2.drawString("GRAFICKS!", 300, 400);

            Face aFace = new Face(0,0,100, Color.blue);
            Face bFace = new Face(200,200,300, Color.CYAN);

            aFace.draw(g2);
            bFace.draw(g2);


        }



        public Color getRandColor(){
            int red = (int)(Math.random()*256);
            int green = (int)(Math.random()*256);
            int blue = (int)(Math.random()*256);
            Color randColor = new Color(red, green, blue);
            return randColor;
        }
        public int getRandX(){
            int x = (int)(Math.random()*getWidth());
            return x;
        }
        public int getRandY(){
            int y = (int)(Math.random()*getHeight());
            return y;
        }
        public int getRandDiameter(){
            int d = (int)(Math.random()*50 + 50);
            return d;
        }


    }

