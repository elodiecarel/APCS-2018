/**
 * Created by student on 9/26/17.
 */
import java.awt.*;

public class Face {

    private int x, y, diameter;
    private Color color;
    public Face(int x, int y, int diameter,Color color){
        this.x =x;
        this.y = y;
        this.diameter = diameter;
        this.color = color;

    }

    public void draw(Graphics2D g2){
        // big oval for head
        // two smaller ovals for eyes
        // an arc for the smile
        g2.setColor(color);
        g2.fillOval(x, y, diameter, diameter);
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(diameter/25));
        g2.fillOval(x + diameter/4, y + diameter/4, diameter/6, diameter/6);
        g2.fillOval(x + diameter/4*3 - diameter/6, y + diameter/4, diameter/6, diameter/6);
      // x, y, w, h start angle, angle length... in degrees
        g2.drawArc(x + diameter/4, y + diameter/4, diameter/2, diameter/2, 200, 140);
    }


}
