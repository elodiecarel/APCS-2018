import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Created by michael_hopps on 4/23/18.
 */
public class ImageFilterMain extends JPanel {

    private ColorSkewedImage myImage;
    private ColorSkewedImage myImage2;
    private NegativeImage neg;
    private Faded fade;
    private FlippedImag flip;

    public ImageFilterMain(int w, int h){
        setSize(w, h);

        myImage = new ColorSkewedImage("testpic.jpg", 0, 0);
        myImage.skewToRed();
       myImage2 = new ColorSkewedImage("testpic.jpg", 600, 400);
       neg = new NegativeImage("testpic.jpg", 600, 0);
       myImage2.skewToGreen();
        fade = new Faded("testpic.jpg", 0, 400);
        fade.fadetoblack();

        flip = new FlippedImag("testpic.jpg", 0, 0);
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        myImage.draw(g2);
       myImage2.draw(g2);
       neg.draw(g2);
        fade.draw(g2);
        flip.draw(g2);

    }

    public static void main(String[] args) {
        //The JFrame class represents the window that holds the graphics
        JFrame window = new JFrame("Graphics!");
        window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window.setBounds(0, 0, 600, 600 + 22); //(x, y, w, h) 22 due to title bar.

        //This puts an object of this JPanel into the JFrame.
        ImageFilterMain panel = new ImageFilterMain(600, 600);

        panel.setFocusable(true);
        panel.grabFocus();

        window.add(panel);
        window.setVisible(true);
//        window.setResizable(false);
    }

}
