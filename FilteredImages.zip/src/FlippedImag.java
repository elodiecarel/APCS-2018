/**
 * Created by student on 5/8/18.
 */
public class FlippedImag extends FilteredImage{

    public FlippedImag(String fileName, int x, int y) {
        super(fileName, x, y);
        flip();

    }

    public FlippedImag(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
        flip();

    }

    public void flip(){
        Pixel[][] pixels = getPixels();

        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[0].length; j++) {

                if (i >= pixels.length/2){
                    pixels[i][j] = pixels [pixels.length - i][j];
                }
            }
        }

        setImage(pixels);
    }
}
