/**
 * Created by student on 5/1/18.
 */
public class NegativeImage extends FilteredImage {

    public NegativeImage(String fileName, int x, int y) {
        super(fileName, x, y);
        makeNegative();
    }

    public NegativeImage(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
        makeNegative();
    }

    public void makeNegative(){
        Pixel[][] pixels = getPixels();
        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[0].length; j++) {
                int blue = pixels[i][j].getBlue();
                int red = pixels[i][j].getRed();
                int green = pixels[i][j].getGreen();

                pixels[i][j].setBlue(255-blue);
                pixels[i][j].setRed(255-red);
                pixels[i][j].setGreen(255-green);
            }
        }
        setImage(pixels);
    }
}
