import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;

/**
 * Created by student on 5/1/18.
 */
public class ColorSkewedImage extends FilteredImage {

    public ColorSkewedImage(String fileName, int x, int y) {
        super(fileName, x, y);
    }

    public ColorSkewedImage(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
    }

    public void skewToRed(){
       Pixel[][] pixels = getPixels();

        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[0].length; j++) {
                pixels[i][j].setBlue(2);
                pixels[i][j].setGreen(2);
            }

        }
        setImage(pixels);
    }

    public void skewToBlue(){
        Pixel[][] pixels = getPixels();

        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[0].length; j++) {
                pixels[i][j].setRed(2);
                pixels[i][j].setGreen(2);
            }

        }
        setImage(pixels);
    }

    public void skewToGreen(){
        Pixel[][] pixels = getPixels();

        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[0].length; j++) {
                pixels[i][j].setBlue(2);
                pixels[i][j].setRed(2);
            }

        }
        setImage(pixels);
    }
}
