/**
 * Created by student on 5/1/18.
 */
public class Faded extends FilteredImage {

    public Faded(String fileName, int x, int y) {
        super(fileName, x, y);
    }

    public Faded(Pixel[][] pixels, int x, int y) {
        super(pixels, x, y);
    }

    public void fadetowhite(){

        Pixel[][] pixels = getPixels();

        int x0 = pixels.length/2;
        int y0 = pixels[0].length/2;

        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[0].length; j++) {

                int x = i;
                int y = j;

                double distance = Math.sqrt((x-x0)*(x-x0)+(y-y0)*(y-y0));

                int alpha = 255 -(int)(distance/pixels.length*255);

                pixels[i][j].setAlpha(alpha);
                }
            }

        setImage(pixels);

        }

    public void fadetoblack(){

        Pixel[][] pixels = getPixels();

        int x0 = pixels.length/2;
        int y0 = pixels[0].length/2;

        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[0].length; j++) {

                int x = i;
                int y = j;

                double distance = Math.sqrt((x-x0)*(x-x0)+(y-y0)*(y-y0));

                double dist = 1- distance/pixels.length;

                pixels[i][j].setRed((int)(pixels[i][j].getRed()*dist));
                pixels[i][j].setBlue((int)(pixels[i][j].getBlue()*dist));
                pixels[i][j].setGreen((int)(pixels[i][j].getGreen()*dist));
            }
        }

        setImage(pixels);

    }

}


