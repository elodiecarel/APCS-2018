import java.awt.*;

/**
 * Created by student on 10/16/17.
 */
public class Revive {

    public void draw(Graphics2D g2, int width, int height){

        int xpoints [] = {width/2+width/8-width/50-width/45,width/2+width/6-width/20-width/45, width/2+width/6-width/20-width/45, width/2+width/8-width/50-width/45};
        int ypoints [] = {width/3+width/16+width/56, width/3+width/15+width/56, width/3+width/20+width/56, width/3+width/22+width/56};
        int npoints = 4;

        g2.setStroke(new BasicStroke(4));
        // basic outline
        g2.drawPolygon(xpoints, ypoints, npoints);

        // basic shape
        g2.setColor(new Color(207, 216, 107));
        g2.fillPolygon(xpoints, ypoints, npoints);

        g2.setStroke(new BasicStroke(1));
        g2.setColor(Color.black);

        // left line
        g2.drawLine(width/2+width/8-width/50-width/45, width/3+width/16+width/56 ,(width/2+width/6-width/20-width/160)-width/45, width/3+width/22+width/32);
        // right line
        g2.drawLine((width/2+width/6-width/20-width/160)-width/45, width/3+width/22+width/32, (width/2+width/6-width/20)-width/45, width/3+width/6-width/10);
        // bottom line
        g2.drawLine(width/2+width/6-width/20-width/45, width/3+width/15+width/56, (width/2+width/6-width/20-width/160)-width/45, width/3+width/22+width/32);
        // top line
        g2.drawLine(width/2+width/8-width/50-width/1000-width/45, width/3+width/15-width/200, (width/2+width/6-width/20-width/160)-width/45, width/3+width/22+width/32);

        int xpointsl [] = {width/2+width/8-width/50-width/45, width/2+width/8-width/50-width/1000-width/45, (width/2+width/6-width/20-width/160-width/45)};
        int ypointsl [] = {width/3+width/16+width/56, width/3+width/15-width/200, width/3+width/22+width/32};
        int npointsl = 3;

        g2.setColor(new Color(1,1,1));
        g2.drawPolygon(xpointsl, ypointsl,npointsl);




    }
}
