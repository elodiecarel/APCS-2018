import java.awt.*;

/**
 * Created by student on 10/19/17.
 */
public class HouseHouse {


        public void draw(Graphics2D g2, int w, int h) {


            int width = w;
            int height = h;

            g2.setStroke(new BasicStroke(20));

            // pokeball, red
            g2.setColor( new Color(255, 35, 35));
            g2.fillOval(width/2-width/3, (width/2-width/3)-width/8, 3*width/5, 3*width/5);

            // pokeball, white
            g2.setColor(Color.white);
            g2.fillArc(width/2-width/3, (width/2-width/3)-width/8,3*width/5, 3*width/5, 180, 180);

            // pokeball, inside
            g2.setColor(Color.darkGray);
            g2.fillArc((width/2-width/3), (width/2-width/3)+width/16, width/2+ width/10, width/4, 0, 360);

            // pokeball, center outline
            g2.setColor(Color.black);
            g2.setStroke(new BasicStroke(12));
            g2.drawArc((width/2-width/3), (width/2-width/3)+width/16,width/2+ width/10, width/4, 0, 360);

            // pokeball, bottom gap
            g2.setColor(Color.darkGray);
            g2.fillOval(width/2-width/3 +width/4, (width/2-width/3)+ width/3 - width/14, width/10, width/10);

            // pokeball, bottom outline gap
            g2.setColor(Color.black);
            g2.drawArc((width/2-width/3 +width/4), (width/2)-width/12, width/10, width/9, 184, 170);

            // pokeball, outer outline
            g2.setStroke(new BasicStroke(18));
            g2.setColor(Color.black);
            g2.drawOval(width/2-width/3, (width/2-width/3)-width/8, 3*width/5, 3*width/5);

            // pokeball, opening notch
            g2.setStroke(new BasicStroke(12));
            g2.setColor(Color.white);
            g2.fillOval(width/2-width/3 +width/4, width/6 + width/100, width/10, width/10);

            // pokeball, opening notch outline
            g2.setColor(Color.black);
            g2.drawOval(width/2-width/3 +width/4, width/6 + width/100, width/10, width/10);


        }


    }


