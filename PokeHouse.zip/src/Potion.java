/**
 * Created by student on 10/13/17.
 */
import javax.swing.plaf.basic.BasicColorChooserUI;
import java.awt.*;

public class Potion {

    int width = this.width;
    int height = this.height;

    public void draw(Graphics2D g2, int width, int height) {

        // potion body
        int rand = (int)(Math.random()*3);
        Color color = null;
        Color color2 = Color.WHITE;
        switch (rand) {
            case 0:
                color = new Color(175, 130, 220);
                break;

            case 1:
                color = new Color(206, 102, 80);
                color2 = Color.YELLOW;
                break;

            case 2:
                color = new Color(255, 112, 213);
                break;
        }

        g2.setColor(color);


        // potion, base
                g2.fillOval(2*width/3 -width/10, width/3-width/120, width/50,width/60);

                // potion, side sticky outie thing
                int xPoints[] = {width/2+width/20+width/100+width/100, width/2+width/20+width/100+width/80, width/2+width/20+width/100+width/40};
                int yPoints[] = {width/3, width/3-width/75, width/3};
                int nPoints = 3;

                g2.fillPolygon(xPoints, yPoints, nPoints);
                g2.fillArc(width/2+width/14, width/3-width/80, width/100, width/100, 90,180);

                // potion, upper base
                g2.fillOval(width/2+width/20+width/50+width/200,width/3-width/60,width/125,width/75);

                // potion, base of nozzle
                g2.setColor(color2);
                g2.fillOval(width/2+width/20+width/50+width/400,width/3-width/60, width/180, width/60);
                g2.fillOval(width/2+width/20+width/50, width/3-width/150, width/120, width/120);
                g2.fillOval(width/2+width/20+width/34, width/3-width/60, width/180, width/140);

                // potion, upper nozzle
                int nozx[] = {2*width/3-width/10,  2*width/3-width/10, 2*width/3-width/20-width/30,  2*width/3-width/20-width/30};
                int nozy [] = {width/3-width/55, width/3-width/80, width/3-width/80, width/3-width/74-width/150};
                int nozn = 4;

                g2.fillPolygon(nozx, nozy, nozn);
                g2.fillOval(2*width/3-width/20-width/26,  width/3-width/50, width/150, width/150);

                g2.setColor(color);
                g2.fillOval(2*width/3-width/10-width/190, width/3-width/55, width/100, width/100);

                g2.setStroke(new BasicStroke(3));
                g2.setColor(Color.black);
                g2.fillOval(2*width/3-width/10-width/1000, width/3-width/70, 3,3);


        rand = (int)(Math.random()*3);
        color2 = Color.WHITE;
        switch (rand) {
            case 0:
                color = new Color(175, 130, 220);
                break;

            case 1:
                color = new Color(206, 102, 80);
                color2 = Color.YELLOW;
                break;

            case 2:
                color = new Color(255, 112, 213);
                break;
        }

        g2.setColor(color);

        g2.fillOval(2*width/3 -width/10+width/20, width/3-width/120, width/50,width/60);

        // potion, side sticky outie thing
        int xPointstoo[] = {width/2+width/20+width/100+width/100+width/20, width/2+width/20+width/100+width/80+width/20, width/2+width/20+width/100+width/40+width/20};
        int yPointstoo[] = {width/3, width/3-width/75, width/3};
        int nPointstoo = 3;

        g2.fillPolygon(xPointstoo, yPointstoo, nPointstoo);
        g2.fillArc(width/2+width/14+width/20, width/3-width/80, width/100, width/100, 90,180);

        // potion, upper base
        g2.fillOval(width/2+width/20+width/50+width/200+width/20,width/3-width/60,width/125,width/75);

        // potion, base of nozzle
        g2.setColor(color2);
        g2.fillOval(width/2+width/20+width/50+width/400+width/20,width/3-width/60, width/180, width/60);
        g2.fillOval(width/2+width/20+width/50+width/20, width/3-width/150, width/120, width/120);
        g2.fillOval(width/2+width/20+width/34+width/20, width/3-width/60, width/180, width/140);

        // potion, upper nozzle
        int nozxtoo[] = {2*width/3-width/10+width/20,  2*width/3-width/10+width/20, 2*width/3-width/20-width/30+width/20, 2*width/3-width/20-width/30+width/20};
        int nozytoo [] = {width/3-width/55, width/3-width/80, width/3-width/80, width/3-width/74-width/150};
        int nozntoo = 4;

        g2.fillPolygon(nozxtoo, nozytoo, nozntoo);
        g2.fillOval(2*width/3-width/20-width/26+width/20,  width/3-width/50, width/150, width/150);

        g2.setColor(color);
        g2.fillOval(2*width/3-width/10-width/190+width/20, width/3-width/55, width/100, width/100);

        g2.setStroke(new BasicStroke(3));
        g2.setColor(Color.black);
        g2.fillOval(2*width/3-width/10-width/1000+width/20, width/3-width/70, 3,3);

// digital color picker

            }

    }

