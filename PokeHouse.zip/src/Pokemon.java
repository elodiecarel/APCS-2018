/**
 * Created by student on 10/12/17.
 */

import javax.imageio.ImageIO;
import javax.swing.plaf.basic.BasicColorChooserUI;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Pokemon {


    public BufferedImage image;
    public int Pokedex;

    public Pokemon() {
        this(null);
    }

    public Pokemon(Pokemon pokemonToExclude) {

        do {
            Pokedex = (int) (Math.random() * 3);
        } while (pokemonToExclude != null && pokemonToExclude.Pokedex == Pokedex);

        switch (Pokedex){

            case 0:
                try {
                  image = ImageIO.read(this.getClass().getResourceAsStream("156.png"));
                    break;
                } catch (IOException ex) {
                    throw new RuntimeException("File not found");
                }

            case 1:
                try {
                image = ImageIO.read(this.getClass().getResourceAsStream("250px-153Bayleef.png"));
                    break;
                }catch (IOException ex) {
                    throw new RuntimeException("File not found");
                }

            case 2: try {
                image = ImageIO.read(this.getClass().getResourceAsStream("159-1.png"));
                break;
            } catch (IOException ex) {
                throw new RuntimeException("File not found");
            }
        }

    }

}