import java.awt.*;
import java.awt.geom.AffineTransform;
import javax.swing.plaf.basic.BasicColorChooserUI;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Created by student on 10/17/17.
 */
public class Background {


    public void paint(Graphics2D g2, int w, int h){

        int width = w/20;
        int height = h/20;

        House backgroundHouse = new House();
        AffineTransform oldXForm = g2.getTransform();

        for (int row = 0; row < 8; row++) {

            g2.setTransform(oldXForm);

            g2.translate(0, 100 * row);

            for (int col = 0 ; col < 12 ; col++) {
                backgroundHouse.draw(g2, 10*width/4, 10*width/4);
                g2.translate(100, 0);

            }
        }
        g2.translate(-1150, -700);

    }


}
