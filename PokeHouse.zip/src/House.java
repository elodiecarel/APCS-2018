


//Elodie Carel

import javax.swing.plaf.basic.BasicColorChooserUI;
import java.awt.*;

public class House {


    public void draw(Graphics2D g2, int w, int h) {


        int width = w;
        int height = h;

        g2.setStroke(new BasicStroke(20));

        // pokeball, red

        int rand = (int)(Math.random()*3);
        Color color = null;
        switch (rand){

            case 0: color =new Color(252,105,105);
                break;

            case 1: color =new Color(252, 155, 52);
                break;

            case 2: color =new  Color (252,35,35);
                break;

            case 3: color =new Color (4, 255, 0) ;
                break;

            case 4: color =new Color(255, 6, 218);
                break;

            case 5: color =new Color(31, 8, 255);
                break;

            case 6: color =new Color(12, 252, 255);
                break;

            case 7: color =new Color(255, 252, 24);
                break;

            case 8: color =new Color(255, 242, 249);
                break;

            case 9: color =new Color(1, 0, 1);
                break;

            case 10: color =new Color(195, 110, 37);
                break;

            case 11: color =new Color(188, 255, 30);
                break;

            case 12: color =new Color(60, 165, 195);
                break;

            case 13: color =new Color(60, 255, 164);
                break;
        }

        g2.setColor( (color));
        g2.fillOval(width/2-width/3, (width/2-width/3)-width/8, 3*width/5, 3*width/5);

        // pokeball, white
        g2.setColor(new Color(255, 255, 255));
        g2.fillArc(width/2-width/3, (width/2-width/3)-width/8,3*width/5, 3*width/5, 180, 180);

        // pokeball, inside
        g2.setColor(Color.darkGray);
        g2.fillArc((width/2-width/3), (width/2-width/3)+width/16, width/2+ width/10, width/4, 0, 360);

        // pokeball, center outline
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(12));
        g2.drawArc((width/2-width/3), (width/2-width/3)+width/16,width/2+ width/10, width/4, 0, 360);

        // pokeball, bottom gap
        g2.setColor(Color.darkGray);
        g2.fillOval(width/2-width/3 +width/4, (width/2-width/3)+ width/3 - width/14, width/10, width/10);

        // pokeball, bottom outline gap
        g2.setColor(Color.black);
        g2.drawArc((width/2-width/3 +width/4), (width/2)-width/12, width/10, width/9, 184, 170);

        // pokeball, outer outline
        g2.setStroke(new BasicStroke(18));
        g2.setColor(Color.black);
        g2.drawOval(width/2-width/3, (width/2-width/3)-width/8, 3*width/5, 3*width/5);

        // pokeball, opening notch
        g2.setStroke(new BasicStroke(12));
        g2.setColor(Color.white);
        g2.fillOval(width/2-width/3 +width/4, width/6 + width/100, width/10, width/10);

        // pokeball, opening notch outline
        g2.setColor(Color.black);
        g2.drawOval(width/2-width/3 +width/4, width/6 + width/100, width/10, width/10);


    }


}
