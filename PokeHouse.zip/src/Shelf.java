/**
 * Created by student on 10/12/17.
 */

import javax.swing.plaf.basic.BasicColorChooserUI;
import java.awt.*;

public class Shelf {

    int width =this.width;
    int height = this.height;


    public void draw(Graphics2D g2, int width, int height){

        // shelf, body outer
        g2.setStroke(new BasicStroke(3));
        g2.setColor(new Color(250, 153, 16));
        g2.fillRect(width/2+width/30, width/3-width/15, width/8, width/6);

        // shelf, interior
        g2.setColor(new Color(225, 128,36));
        g2.fillRect((width/2+width/30)+ width/75,(width/3-width/15)+ width/70, width/10, width/16);
        g2.fillRect((width/2+width/30)+width/75, (width/3-width/15)+width/11, width/10, width/16 );

        g2.setColor(Color.black);
        // shelf, interior outlines
        // top
        // top
        g2.drawLine((width/2+width/30)+ width/75,(width/3-width/15)+ width/70, (width/2+width/30)+ width/10+ width/85,(width/3-width/15)+ width/70);
       // bottom
        g2.drawLine((width/2+width/30)+ width/75,(width/3-width/15)+ width/15+ width/88, (width/2+width/30)+ width/10+ width/85,(width/3-width/15)+ width/15+ width/88);
       // left
        g2.drawLine((width/2+width/30)+ width/75,(width/3-width/15)+ width/70, (width/2+width/30+ width/75), width/3+ width/90);
        // right
        g2.drawLine((width/2+width/30)+ width/10+ width/85, (width/3-width/15)+ width/70,(width/2+width/30)+ width/10+ width/85 , width/3+ width/90);

        // bottom
        // top
        g2.drawLine((width/2+width/30)+ width/75, (width/3-width/15)+ width/10- width/90, (width/2+width/30)+ width/10+ width/85, (width/3-width/15)+ width/10- width/90);
        // bottom
        g2.drawLine((width/2+width/30)+ width/75, (width/3-width/15)+ width/10 + width/19, (width/2+width/30)+ width/10+ width/85, (width/3-width/15)+ width/10 + width/19);
        // left
        g2.drawLine((width/2+width/30)+ width/75, width/3+ width/40, (width/2+width/30+ width/75), width/3+ width/12);
        // right
        g2.drawLine((width/2+width/30)+ width/10+ width/85, width/3+ width/40, (width/2+width/30)+ width/10+ width/85, width/3+ width/12);


        // there was a significantly easier way to do this....
        // should have made two rectangles
        // don't do that again

        // shelf, exterior outlines
        g2.drawRect(width/2+width/30, width/3-width/15, width/8, width/6);

        // if time allows, go back and add some depth into shelves using polygons

    }

}
