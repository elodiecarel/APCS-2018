import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


/**
 * Created by Elodie Carel on 10/2/17.
 */

public class HousePanel extends JPanel {

    private Pokemon Pokemon;

    public HousePanel(int width, int height) {
        setSize(width, height);
        Pokemon = new Pokemon();

        addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {

                Pokemon = new Pokemon(Pokemon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

    }


    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        repaint();

        Background background = new Background();
        background.paint(g2, getWidth(), getHeight());

        HouseHouse mainhouse = new HouseHouse();

        mainhouse.draw(g2, getWidth(), getHeight());

        Shelf shelf = new Shelf();
        shelf.draw(g2, getWidth(), getHeight());

        Potion potion = new Potion();
        potion.draw(g2, getWidth(), getHeight());

        g2.drawImage(Pokemon.image, getWidth() / 4, getWidth() / 4, getWidth() / 6, getWidth() / 6, this);

        Revive revive = new Revive();
        revive.draw(g2, getWidth(), getHeight());


    }

}


