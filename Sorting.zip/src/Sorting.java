import java.util.ArrayList;

/**
 * Created by student on 4/9/18.
 */
public class Sorting {


    public int min(int[] arr, int start)  //Used by selSort
    {
        int min = start;
        for(int i = start + 1; i < arr.length; i++)
            if(arr[i] < arr[min])
                min = i;
        return min;
    }



    public static void sortByLength( ArrayList<String> list ) {
        for (int i = 1; i < list.size(); i++) {
            int j = i;
            while (j >= 1 && list.get(j).length() < list.get(j-1).length()) {

                String temp = list.get(i);
                list.set(i, list.get(j));
                list.set(j, temp);
                
                j--;
            }
        }

    }


}
