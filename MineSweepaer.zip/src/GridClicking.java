import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// elodie
// press m key for an easter egg

public class GridClicking extends JPanel {
    private int[][] board;
    private boolean[][] revealed;
    private int numberRevealed;
    private boolean[][] flags;
    private int size;
    private JButton replay;

    private final int flagSize = 10;
    private final int offset = 10;
    private final int numMines = 30;

    private boolean isKaboomed;
    private boolean hasWon;
    private boolean firstClick;

    private boolean showMines;

    public GridClicking(int width, int height) {
        setSize(width, height);
        size = 30;
        setupMouseListener();
        setupKeyListener();

        this.setLayout(null);

        replay = new JButton("Replay");
        //replay.setVisible(false)
        replay.setBounds(offset + 200, offset + size * 15 + 45, 100, 30);
        this.add(replay);
        replay.setFont(new Font ("ArcadeClassic", Font.BOLD, 20));
        replay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                initGame();
                repaint();
            }
        });

        initGame();
    }

    private void initGame() {
        board = new int[15][15];
        revealed = new boolean[15][15];
        flags = new boolean[15][15];
        showMines = false;
        firstClick = true;
        plantMines(numMines);
        isKaboomed = false;
        hasWon = false;
        this.grabFocus();
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        if (isKaboomed) {
            g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 46));
            g2.drawString("GAME OVER!", offset, offset + size * 15 + 45);
        }

        if (hasWon) {
            g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 46));
            g2.drawString("YOU WIN!", offset, offset + size * 15 + 45);
        }

        for (int r = 0; r < board.length; r++)

            for (int c = 0; c < board[0].length; c++) {

                if (!revealed[r][c]) {
                    g2.setColor(Color.gray);
                    g2.fillRect(offset + c * size, offset + r * size, size, size);
                }

                // flag
                if (flags[r][c]) {
                    Color flagColor = isKaboomed && board[r][c] == -1
                            ? Color.blue
                            : Color.red;
                    g.setColor(flagColor);
                    g.fillRect(offset + c * size + flagSize / 2, offset + r * size + flagSize / 2, size - flagSize, size - flagSize);
                    drawBorder(g2, r, c);
                    continue;
                }

                // mine
                if (board[r][c] == -1 && (hasWon || isKaboomed || showMines)) {
                    g2.setColor(Color.black);
                    g2.fillRect(offset + c * size, offset + r * size, size, size);
                }

                drawBorder(g2, r, c);

                int sum = numMines(r,c);
                String sums = ""+ sum;

                // number of neighboring mines
                if (sum != 0 && revealed[r][c]) {
                    g2.setColor(Color.black);
                    g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 20));
                    g2.drawString(sums, offset + c * size + size / 2 - 4, offset + r * size + size / 2 + 4);
                }

            }

    }

    private void drawBorder(Graphics2D g2, int r, int c) {
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(4));
        g2.drawRect(offset + c * size, offset + r * size, size, size);
    }

    public void revealCell(int r, int c){
        //System.out.println("row " + r + "; col " + c);

        if (!isLegal(r, c)) return;

        if (!revealed[r][c]){
            revealed[r][c] = true;
            numberRevealed++;

            if (numMines(r,c) == 0 && board[r][c] == 0) {

                revealCell(r - 1, c);
                revealCell(r + 1, c);
                revealCell(r, c - 1);
                revealCell(r, c + 1);

                revealCell(r + 1, c - 1);
                revealCell(r - 1, c - 1);
                revealCell(r - 1, c + 1);
                revealCell(r + 1, c + 1);
            }
        }

        if (board.length * board[0].length - numMines == numberRevealed) {
            hasWon = true;
        }
    }

    public boolean isLegal(int r, int c){
        if (r > -1 && r < board.length && c > -1 && c < board[0].length)
            return true;

        return false;
    }

    public void plantMines(int num){
        int n = 0;

        while (n < num){
            int r = (int)(Math.random()*board.length);
            int c = (int)(Math.random()*board[0].length);
            if (board [r][c] != -1){
                board[r][c] = -1;
                n++;
            }
        }
        int[][] minetracker = new int[board.length][board[0].length];
        for (int r = 0; r < board.length; r++) {
            for (int c = 0; c < board[0].length; c++) {
                if (board[r][c]!= -1)
                    minetracker[r][c] = numMines(r,c);
                else
                    minetracker[r][c] = -1;
            }
        }

    }

    public int numMines(int r, int c){
        int sum = 0;
        if( isLegal(r-1, c-1) == true && board[r-1][c-1] == -1)
            sum++;
        if( isLegal(r-1, c) == true && board[r-1][c] == -1)
            sum++;

        if( isLegal(r-1, c+1) == true && board[r-1][c+1] == -1)
            sum++;

        if( isLegal(r, c-1) == true && board[r][c-1] == -1)
            sum++;

        if( isLegal(r, c+1) == true && board[r][c+1] == -1)
            sum++;

        if( isLegal(r+1, c-1) == true && board[r+1][c-1] == -1)
            sum++;

        if( isLegal(r+1, c) == true && board[r+1][c] == -1)
            sum++;

        if( isLegal(r+1, c+1) == true && board[r+1][c+1] == -1)
            sum++;

        return sum;

    }

    public void setupKeyListener() {
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyChar() !=  'M' && e.getKeyChar() != 'm') {
                    return;
                }

                showMines = !showMines;
                repaint();
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
    }

    public void setupMouseListener(){

//  a different type of mouse listener
//          _,
//         //      /)/)
//        ||      / ..\
//        \\.----' ,_Y/
//         \        (
//         l  \_/   |
//         | /`/| //
//         \_)_)\_))

        addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {

                if (isKaboomed || hasWon) return;

                int x = e.getX() - offset;
                int y = e.getY() - offset;

                int r = y / size;
                int c = x / size;

                if (e.isControlDown() && !revealed[r][c]) {
                    flags[r][c] = !flags[r][c];
                    firstClick = false;
                    repaint();
                    return;
                }

                if (flags[r][c]) {
                    repaint();
                    firstClick = false;
                    return;
                }

                if (board[r][c] == -1) {
                    if (!firstClick) {
                        isKaboomed = true;

                        for (int r1 = 0; r1 < board.length; r1++) {
                            for (int c1 = 0; c1 < board[0].length; c1++) {
                                revealed[r1][c1] = true;
                            }
                        }
                    } else {
                        boolean noMineAtClick = false;
                        do {
                            board = board = new int[15][15];
                            plantMines(numMines);
                            noMineAtClick = board[r][c] != -1;
                         } while (!noMineAtClick);

                        revealCell(r, c);
                    }

                } else {
                    revealCell(r, c);
                }

                repaint();
                firstClick = false;
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    //sets ups the panel and frame.  Probably not much to modify here.
    public static void main(String[] args) {
        JFrame window = new JFrame("Click!");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setBounds(0, 0, 600, 600 + 22); //(x, y, w, h) 22 due to title bar.

        int a = 600;
        int b = 600;
        GridClicking panel = new GridClicking(a, b);

        panel.setFocusable(true);
        panel.grabFocus();

        window.add(panel);
        window.setVisible(true);
        window.setResizable(false);
    }

}



/*
Sorting Algorithms!

- data structure
    putting it in order

- usually least to greatest (ascending)
    can be decending as well

Big 3:

- Selection Sort
    repeated minimum algorithm
    finds the smallest value that already isnt a minimum

- Insertion Sort
    swap elements down to proper position


- Merge Sort

 */