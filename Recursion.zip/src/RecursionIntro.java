/**
 * Created by student on 2/26/18.
 */
public class RecursionIntro {

    /*
    Recursion: have a method call itself on purpose
    another way of looping or repeating code
    infinite recursion == bad;

    powerful, but dangerous! Can use ALL the memory available
    very quickly.

    Check for an end case or it will never stop

    factorial -> 4! = 4*3*2*1

    4! = 4 * 3!

    1! is the base case
     */
    public static void main(String[] args) {

     permutations("WORD");

    }

    // long is a 64 bit integer vs 32

    public static long factorial(long n){
        if (n == 1)
            return 1;
        return n*factorial(n-1);
    }

    public static int fibonacci(int n){
        if (n == 1 || n == 2)
            return 1;

        n = fibonacci(n-1) + fibonacci(n-2);
        return n;
    }

    // gohangasalamiimalasagnahog
    // precondition: no spaces or punctuation... all lower case
    public static boolean isPalindrome(String word){
        if (word.length() <= 1)
            return true;

        String first = word.substring(0,1);
        String last = word.substring(word.length()-1);

        if (first.equals(last)){
           return isPalindrome(word.substring(1, word.length()-1));
        }
        return false;
    }

    public static void permutations(String word){
        permutations("", word);
    }

    public static void permutations(String prefix, String ending){
       if (ending.length() == 1){
           System.out.println(prefix + ending);
       }
       else {
           for (int i = 0; i < ending.length(); i++) {
               String a = ending.substring(i, i+1);
               String b = ending.substring(0,i) + ending.substring(i+1);
               permutations(prefix + a, b);
           }
       }

    }
}
