/**
 * Created by student on 3/7/18.
 */
public class Searcher {

    //

    private int[] arr;

    public Searcher(int [] arr){
        this.arr = arr;

    }

    public int sequentialSearch(int key){
        for (int i = 0; i < arr.length; i++) {
            if(key == arr[i])
                return i;
        }
        return -1;
    }

    public int sequentialSearchRecursive(int key, int i){
        if (key == arr[i]){
            return i;
        }
        if (i == arr.length-1){
            return -1;
        }
        return  sequentialSearchRecursive(key, i+1);
    }

    public int binarySearch(int key){
        int hi = arr.length-1;
        int lo = 0;
        int mid;

        while(lo <= hi){
            mid = (hi + lo)/2;
            if (key == arr[mid])
                return mid;
            else if (key < arr[mid])
                hi = mid - 1;
            else
                lo = mid +1;
        }
        return -1;
    }

    public int binarySearchReursion(int key, int low, int high){
        if (low > high)
            return -1;
        int mid = (low + high)/2;
        if (key == arr[mid])
            return mid;

        if (key > arr[mid])
           return binarySearchReursion(key, mid + 1, high);

        else
           return binarySearchReursion(key, low, mid - 1);
    }
}
