import javax.swing.*;
import java.awt.*;

/**
 * Created by michael_hopps on 10/26/17.
 */
public class BallPanel extends JPanel {

    public BallPanel(int w, int h){
        setSize(w, h);

    }

    public void paintComponent(Graphics g){
        Graphics2D g2 = (Graphics2D)g;

    }
}
