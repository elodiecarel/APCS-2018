import turtle as t

bob = t.Turtle()
bob.speed(100)

def kochCurve(depth, length):
    if depth == 0:
       bob.forward(length)

    else:
        kochCurve(depth-1, length/3)
        bob.left(60)
        kochCurve(depth - 1, length / 3)
        bob.right(120)
        kochCurve(depth - 1, length / 3)
        bob.left(60)
        kochCurve(depth - 1, length / 3)

def snowflake(depth, length):
    kochCurve(depth - 1, length / 3)
    bob.right(120)
    kochCurve(depth - 1, length / 3)
    bob.right(120)
    kochCurve(depth - 1, length / 3)

def tree(depth, length):
    if depth == 0:
        bob.forward(length)
        bob.backward(length)

    else:
        angle = 30
        bob.forward(length)
        bob.right(angle)
        tree(depth-1, length*.8)
        bob.left(2*angle)
        tree(depth - 1, length *.8)
        bob.right(angle)
        bob.back(length)

def sirpinski(depth, length):
    if depth == 0:
        bob.left(60)
        bob.forward(length)
        bob.right(120)
        bob.forward(length)
        bob.left(240)
        bob.forward(length)
        bob.right(180)


    else:

        sirpinski(depth-1, length/2)
        bob.forward(length/2)
        sirpinski(depth-1, length/2)
        bob.left(120)
        bob.forward(length/2)
        bob.right(120)
        sirpinski(depth-1, length/2)
        bob.left(60)
        bob.back(length/2)
        bob.right(60)




bob.penup()
bob.setposition(-200, -100)
bob.pendown()
#bob.tracer(False)
#bob.left(90)
#bob.backward(300)
#tree(13, 100)

sirpinski(8, 500)

t.done()