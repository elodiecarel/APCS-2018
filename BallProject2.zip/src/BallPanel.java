import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by michael_hopps on 10/26/17.
 */
public class BallPanel extends JPanel {

    private Ball[] theBalls;
    private int counter;

    public BallPanel(int w, int h){
        setSize(w, h);

        // initialize theBalls array

        // first, create the actual array
        // second, make new Ball objects and put them in the array
        theBalls = new Ball[200];
        for (int i = 0; i <theBalls.length ; i++) {
            int x = (int)(Math.random()* getWidth());
            int y = (int)(Math.random() * getHeight());
            int vx = (int)(Math.random()*(17-8));
            int vy = (int)(Math.random()*(17-8));

            theBalls[i] = new Ball(getWidth()/2 -25,getHeight()/2 -25,vx,vy);

        }

        Timer timer = new Timer(1000/60, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // anything in here happens every 25ms.
                counter++;
                for (Ball b: theBalls) {
                    b.move(getWidth(),getHeight());
                }
                repaint();
            }
        });
        timer.start();
    }
// timer: actionEvent on a fixed time interval
    // delay is measured in milliseconds

    public void paintComponent(Graphics g){
        Graphics2D g2 = (Graphics2D)g;
        for (Ball b: theBalls) {
            b.draw(g2);
             if (counter % 120 == 0){
                 b.randomColor();
             }


        };

    }
}
