/**
 * Created by student on 11/6/17.
 */
public class Main {
    public static void main(String[] args) {
        String myString = "something";

        printVertical(myString);
        System.out.println(reverse(myString));
    }

    public static void printVertical(String str) {
        for (int i = 0; i < str.length(); i++) {
            System.out.println(str.substring(i, i + 1));
        }
    }

    public static String reverse(String str) {
        String rev = "";
        for (int i = str.length(); i > 0; i--) {
            String a = str.substring(i - 1, i);

            rev = rev + a;
            System.out.println(a);

        }

        return rev;
    }

    public static int count(String word, String letter) {
        // returns the number of times letter appears in word

        // Option 1: forloop, substring if statement--> if letter is letter
        // Option 2: while loop! indexOf.
        // it's like a forloop but easier

        int count = 0;
        int i = word.indexOf(letter);

        while (i > -1) {
            count++;
            word.indexOf(letter, i + 1);
        }
        return count;

    }
}

// if you call something from the main, you can say static and then it works
// static exists without object