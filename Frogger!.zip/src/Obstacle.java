/**
 * Created by michael_hopps on 2/14/17.
 */
public class Obstacle extends Sprite {

    private double dirmath;
    private int dir;


    public Obstacle(int x, int y){
        super(x, y, EAST );

        setPic("car1.png", EAST);
        dirmath = Math.random();
            if(dirmath < .5 ){
                dir = 0;
            }
            else
                dir = 180;
        setDir(dir);

    }

    @Override

    public void update(){

        setSpeed((getBoundingRectangle().height)/2);

        super.update();
    }
}
