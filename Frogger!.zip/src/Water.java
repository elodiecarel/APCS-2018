/**
 * Created by student on 2/7/18.
 */
import java.awt.*;
public class Water extends Obstacle
{


    private Point p;

    public Water(int x, int y){
        super(x, y);
        p = new Point (0, 100);
        setPic("Water.png", EAST);
        setLoc(p);
    }

    @Override

    public void update(){
        setSpeed(0);

    }

}
