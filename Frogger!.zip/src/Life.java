

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.awt.image.BufferedImage;
import java.io.File;


/**
 * Created by student on 2/6/18.
 */
public class Life   {

    private int lifetotal;
    private int hits;
    private int lifeleft;
    private Frog f;
    private Log l;
    private BufferedImage pic;
    private int picOrientation;


    public Life(int lifetotal, Frog f){
        this.lifetotal = lifetotal;
        hits = 0;
        lifeleft = lifetotal - hits;
        this.f= f;
        this.l = l;
        picOrientation = 90;
        setPic("Heart.png", picOrientation);
    }

    public int lifeCalc(){
        return lifeleft;
    }

    public boolean keepGoing(){
        if (lifeleft <= 0)
            return false;

        else
            return true;
    }
    public void hit(){
        hits++;
        System.out.println("life left: " + lifeleft);
    }

    public void updatelife(){

        lifeleft = lifetotal - hits;
    }

    public void setPic(String fileName, int orientation) {
        try {
            pic = ImageIO.read(new File("res/" + fileName));
            picOrientation = orientation;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void setPic(BufferedImage pic) {
        this.pic = pic;
    }


    public void draw(Graphics2D g2) {

        for (int i = 0; i <lifeleft ; i++) {
            g2.drawImage(pic, 30+ i*100, 520, null);
        }


//        g2.draw(getBoundingRectangle());
    }
}

