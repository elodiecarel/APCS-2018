import java.awt.*;

/**
 * Created by student on 2/7/18.
 */
public class FroggerGraphicsTwo {
    public static final int FW = 1000, FH = 600;

    public static void draw(Graphics2D g2){
        g2.setColor(new Color (28, 255, 143));
        g2.fillRect(0, 0, FW, FH);

    }
}
