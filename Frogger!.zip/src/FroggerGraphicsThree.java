import javax.swing.*;
import java.awt.*;

/**
 * Created by student on 2/11/18.
 */
public class FroggerGraphicsThree extends JPanel {
    public static final int FW = 1000, FH = 600;

    public static void draw(Graphics2D g2) {

        // background
        g2.setColor(new Color (28, 255, 143));
        g2.fillRect(0, 0, FW, FH);

        // road1
        g2.setColor(new Color (150, 150, 150));
        g2.fillRect(0, 360, FW, 90);

        // road lines1
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(5));
        g2.drawLine(0, 360, FW, 360);
        g2.drawLine(0, 390, FW, 390);
        g2.drawLine(0, 420, FW, 420);
        g2.drawLine(0, 450, FW, 450);



    }
}
