import javax.swing.*;
import java.awt.*;

/**
 * Created by student on 2/7/18.
 */
public class FroggerGraphics extends JPanel {

    public static final int FW = 1000, FH = 600;

    public static void draw(Graphics2D g2) {

        // background
        g2.setColor(new Color (28, 255, 143));
        g2.fillRect(0, 0, FW, FH);

        // road1
        g2.setColor(new Color (150, 150, 150));
        g2.fillRect(0, 300, FW, 210);

        // road lines1
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(5));
        g2.drawLine(0, 300, FW, 300);
        g2.drawLine(0, 330, FW, 330);
        g2.drawLine(0, 360, FW, 360);
        g2.drawLine(0, 390, FW, 390);
        g2.drawLine(0, 420, FW, 420);
        g2.drawLine(0, 450, FW, 450);
        g2.drawLine(0, 480, FW, 480);
        g2.drawLine(0, 510, FW, 510);

        // road 2
        g2.setColor(new Color (150, 150, 150));
        g2.fillRect(0, 40, FW, 210);

        // road lines2
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(5));
        g2.drawLine(0, 40, FW, 40);
        g2.drawLine(0, 70, FW, 70);
        g2.drawLine(0, 100, FW, 100);
        g2.drawLine(0, 130, FW, 130);
        g2.drawLine(0, 160, FW, 160);
        g2.drawLine(0, 190, FW, 190);
        g2.drawLine(0, 220, FW, 220);
        g2.drawLine(0, 250, FW, 250);


    }



}
