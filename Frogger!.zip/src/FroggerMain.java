import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.Font;

//Elodie Carel

public class FroggerMain extends JPanel {

    //instance fields for the general environment
    public static final int FRAMEWIDTH = 1000, FRAMEHEIGHT = 600;
    private Timer timer;
    private boolean[] keys;
    private int hit;
    private int level;

    //instance fields for frogger.
    private Frog frog;
    private ArrayList<Obstacle> obstacles;
    private Life life;
    private ArrayList<Log> log;

    private JButton restart;
    private JButton quit;

    private boolean oneKeyPressed;

    public FroggerMain(int level, int lifes){

        setLayout(null);

        keys = new boolean[512]; //should be enough to hold any key code.
        //TODO: initialize the instance fields.
        frog = new Frog();
        hit = 0;
        life = new Life(lifes, frog);
        this.level = level;

        restart = new JButton("Play again");
        restart.setBounds(300, 250, 200, 150);
        restart.setVisible(false);
        add(restart);
        restart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                init(1, 3);
            }
        });

        quit = new JButton("Quit");
        quit.setBounds(550, 250, 100, 150);
        quit.setVisible(false);
        add(quit);

        quit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        //TODO: init obstacles arraylist

        log = new ArrayList<Log>();
        Log logl = new Log(20, 300, 20);
        Log logl2 = new Log(20, 450, 10);
        Log logl3 = new Log(20, 400, 15);
        Log logl4 = new Log(20, 350, 5);
        Log logl5 = new Log(20, 250, 17);
        Log logl6 = new Log(20, 200, 23);
        Log logl7 = new Log(20, 150, 12);
        Log logl8 = new Log(20, 100, 18);

        obstacles = new ArrayList<Obstacle>();
        // obstacles for level 1
        Obstacle obs = new Obstacle(900, 305);
        Obstacle obs2 = new Obstacle(100, 335);
        Obstacle obs3 = new Obstacle(630, 365);
        Obstacle obs4 = new Obstacle(500, 395);
        Obstacle obs5 = new Obstacle(800, 425);
        Obstacle obs6 = new Obstacle(300, 455);
        Obstacle obs7 = new Obstacle(150, 485);

        Obstacle obs8 = new Obstacle(150, 45);
        Obstacle obs9 = new Obstacle(350, 75);
        Obstacle obs10 = new Obstacle(550, 105);
        Obstacle obs11 = new Obstacle(750, 135);
        Obstacle obs12 = new Obstacle(950, 165);
        Obstacle obs13 = new Obstacle(400, 195);
        Obstacle obs14 = new Obstacle(600, 225);

        Log logl9 = new Log(20, 338, 5);
        Log logl10 = new Log(50, 288, 15);
        Log logl11 = new Log(400, 238, 12);
        Log logl12 = new Log(800, 188, 25);
        Log logl13 = new Log(700, 138, 12);
        Log logl14 = new Log(200, 88, 17);

        Water waterObstacle = new Water(500, 395);
        Water waterObstacle2 = new Water(0, 0);

        Boss DK = new Boss(50, 250, frog);
        DK.setPic("DK.png", Sprite.EAST);

        Boss Inky = new Boss(900, 250, frog);
        Inky.setPic("inky.png", Sprite.EAST);

        Boss Bowser = new Boss(450, 50, frog);
        Bowser.setPic("Bowser.png", Sprite.EAST);

        Boss alienOne = new Boss(50, 50, frog);
        alienOne.setPic("alien.png", Sprite.EAST);

        Boss alienTwo = new Boss(900, 50, frog);
        alienTwo.setPic("alien.png", Sprite.EAST);


        switch (level) {
            case 1:
                obstacles.add(obs);
                obstacles.add(obs2);
                obstacles.add(obs3);
                obstacles.add(obs4);
                obstacles.add(obs5);
                obstacles.add(obs6);
                obstacles.add(obs7);

                obstacles.add(obs8);
                obstacles.add(obs9);
                obstacles.add(obs10);
                obstacles.add(obs11);
                obstacles.add(obs12);
                obstacles.add(obs13);
                obstacles.add(obs14);
                break;

            case 2:
                obstacles.add(waterObstacle);
                log.add(logl);
                log.add(logl2);
                log.add(logl3);
                log.add(logl4);
                log.add(logl5);
                log.add(logl6);
                log.add(logl7);
                log.add(logl8);
                break;

            case 3:
                for (int yObs = 365 ; yObs <= 425; yObs = yObs + 30) {
                    for (int xObs = 0; xObs <= 990; xObs = xObs + 30) {
                        Obstacle obsta = new Obstacle(xObs, yObs);
                        obsta.setSpeed(0);
                        obstacles.add(obsta);
                    }
                    Obstacle def = new Obstacle(60, 425);
                    def.setSpeed(0);
                    def.setPic("car1 copy.png", Sprite.EAST);
                    obstacles.add(def);

                }
                obstacles.add(waterObstacle2);
                waterObstacle2.setPic("Water2.png", Sprite.EAST);

                log.add(logl9);
                log.add(logl10);
                log.add(logl11);
                log.add(logl12);
                log.add(logl13);
                log.add(logl14);
                break;

            case 4:
                obstacles.add(DK);
                obstacles.add(Inky);
                obstacles.add(Bowser);
                obstacles.add(alienOne);
                obstacles.add(alienTwo);
                break;

        }

        //TODO: add obstacles - cars and stuff


        timer = new Timer(40, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //System.out.println(obstacles.size());
                //move the frog
                if(keys[KeyEvent.VK_UP] && frog.getLoc().y > 0){
                    frog.setDir(Sprite.NORTH);
                    frog.update();
                    keys[KeyEvent.VK_UP] = false; //probably.  Makes 1 move per button press.
                }

                if(keys[KeyEvent.VK_LEFT] && frog.getLoc().x > 0){
                    frog.setDir(Sprite.WEST);
                    frog.update();
                    keys[KeyEvent.VK_LEFT] = false; //probably.  Makes 1 move per button press.
                }

                if(keys[KeyEvent.VK_DOWN]){
                    frog.setDir(Sprite.SOUTH);
                    if (frog.getLoc().y < FRAMEHEIGHT - 2*frog.getBoundingRectangle().getHeight())
                        frog.update();
                    keys[KeyEvent.VK_DOWN] = false; //probably.  Makes 1 move per button press.
                }

                if(keys[KeyEvent.VK_RIGHT]){
                    frog.setDir(Sprite.EAST);
                    if (frog.getLoc().x < FRAMEWIDTH - 2*frog.getBoundingRectangle().getWidth())
                        frog.update();
                    keys[KeyEvent.VK_RIGHT] = false; //probably.  Makes 1 move per button press.
                }
                //TODO: implement other directions

                if(keys[KeyEvent.VK_SPACE]){
                    if(timer.isRunning()) {
                        timer.stop();
                    }
                    else {
                        timer.start();
                    }
                }

                if (frog.endZone()) {
                    levelUp();
                }
                if (level == 3) {
                    frog.portal();
                }

                //TODO: update each obstacle

                // add a switch for the cases here

                switch (level){
                    case 1:
                        for (int i = 0; i < obstacles.size(); i++) {
                            if(obstacles.get(i).getLoc().x < FRAMEWIDTH && obstacles.get(i).getLoc().x > 0)
                                obstacles.get(i).update();

                            else {

                                obstacles.get(i).setDir(Math.abs(obstacles.get(i).getDir()-180));
                                obstacles.get(i).update();
                            }
                        }
                        break;

                    case 2:
                        for (int i = 0; i < obstacles.size(); i++) {
                            if(obstacles.get(i).getLoc().x < FRAMEWIDTH && obstacles.get(i).getLoc().x > 0)
                                obstacles.get(i).update();
                        }
                        for (int i = 0; i < log.size(); i++) {
                            int currentLogX = log.get(i).getLoc().x;

                            if(log.get(i).getLoc().x < FRAMEWIDTH - log.get(i).getBoundingRectangle().width && log.get(i).getLoc().x > 0){
                                log.get(i).update();
                            }
                            else {
                                log.get(i).setDir(Math.abs(log.get(i).getDir()-180));
                                log.get(i).update();
                            }

                            if (log.get(i).getHasFrog()) {
                                frog.getLoc().x += log.get(i).getLoc().x - currentLogX;
                            }

                        }

                        break;

                    case 3:
                        for (int i = 0; i < log.size(); i++) {
                            int currentLogX = log.get(i).getLoc().x;

                            if(log.get(i).getLoc().x < FRAMEWIDTH - log.get(i).getBoundingRectangle().width && log.get(i).getLoc().x > 0){
                                log.get(i).update();
                            }
                            else {
                                log.get(i).setDir(Math.abs(log.get(i).getDir()-180));
                                log.get(i).update();
                            }

                            if (log.get(i).getHasFrog()) {
                                frog.getLoc().x += log.get(i).getLoc().x - currentLogX;
                            }

                        }
                        break;

                    case 4:
                        for (int i = 0; i < obstacles.size(); i++) {
                            obstacles.get(i).update();
                        }
                        break;

                   // playAgain();
                }

                //TODO: check for collisions - frog vs obstacles

                //System.out.println(frog.getLoc());
                Point p = new Point(500, 550);
                for (int i = 0; i < obstacles.size(); i++) {

                    if (!frog.intersects(obstacles.get(i))) continue;

                    if (level == 1) {
                        frog.setLoc(p);
                        frog.setDir(Sprite.NORTH);
                        life.hit();
                        life.updatelife();
                    } else if (level == 2) {
                        boolean onLog = false;
                        for (int j = 0; j < log.size(); j++) {
                            onLog = onLog || log.get(j).intersects(frog);
                            log.get(j).setHasFrog(log.get(j).intersects(frog));
                        }
                        if (!onLog) {
                            frog.setLoc(p);
                            frog.setDir(Sprite.NORTH);
                            life.hit();
                            life.updatelife();
                        }
                    }
                    else if(level == 3 && frog.getLoc().y > 360){
                        frog.setLoc(p);
                        frog.setDir(Sprite.NORTH);
                        life.hit();
                        life.updatelife();
                    }

                    else if(level == 3 && frog.getLoc().y <360){
                        boolean onLog = false;
                        for (int j = 0; j < log.size(); j++) {
                            onLog = onLog || log.get(j).intersects(frog);
                            log.get(j).setHasFrog(log.get(j).intersects(frog));
                        }
                        if (!onLog) {
                            frog.setLoc(p);
                            frog.setDir(Sprite.NORTH);
                            life.hit();
                            life.updatelife();
                        }
                    }
                    else if(level==4){
                        frog.setLoc(p);
                        frog.setDir(Sprite.NORTH);
                        life.hit();
                        life.updatelife();
                    }
                }

                repaint(); //always the last line.  after updating, refresh the graphics.
            }
        });
        timer.start();

        /*
        You probably don't need to modify this keyListener code.
         */
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {/*intentionally left blank*/ }

            //when a key is pressed, its boolean is switch to true.
            @Override
            public void keyPressed(KeyEvent keyEvent) {
                oneKeyPressed = true;
                keys[keyEvent.getKeyCode()] = true;
            }

            //when a key is released, its boolean is switched to false.
            @Override
            public void keyReleased(KeyEvent keyEvent) {
                keys[keyEvent.getKeyCode()] = false;
            }
        });

    }

    //Our paint method.
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;

        switch (level){
            case 1:
                FroggerGraphics.draw(g2);
                for (int i = 0; i < obstacles.size(); i++) {
                    obstacles.get(i).draw(g2);
                }
                    break;
            case 2:
                FroggerGraphicsTwo.draw(g2);
                for (int i = 0; i < obstacles.size(); i++) {
                    obstacles.get(i).draw(g2);
                }
                    for (int i = 0; i < log.size() ; i++) {
                    log.get(i).draw(g2);
                }
                break;

            case 3:
                FroggerGraphicsThree.draw(g2);
                for (int i = 0; i < obstacles.size(); i++) {
                    obstacles.get(i).draw(g2);
                }
                for (int i = 0; i < log.size(); i++) {
                    log.get(i).draw(g2);
                }
                break;

            case 4:
                if (!oneKeyPressed)
                    FroggerGraphicsFour.draw(g2);
                else
                    FroggerGraphicsTwo.draw(g2);

                if (frog.getLoc().y < 500) {
                    for (int i = 0; i < obstacles.size(); i++) {
                        ((Boss)obstacles.get(i)).setTrackFrog(true);
                    }
                }

                for (int i = 0; i < obstacles.size(); i++) {
                    Boss boss = (Boss)obstacles.get(i);
                    if (boss.isTrackFrog()) {
                        boss.draw(g2);
                    }
                    repaint();
                }
                break;

            case 5:
                FroggerGraphicsTwo.draw(g2);
                g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 70));
                g2.setColor(Color.black);
                g2.drawString("YOU WON!!!", 320, 200);
                g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 20));
                //game over display
                restart.setVisible(true);
                restart.setFont(g2.getFont());

                quit.setVisible(true);
                quit.setFont(g2.getFont());
                break;

        }

        if(life.keepGoing()) {
            frog.draw(g2);
            life.draw(g2);
        }
        else{
            FroggerGraphicsTwo.draw(g2);
            g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 70));
            g2.setColor(Color.red);
            g2.drawString("YOU LOST", 340, 200);
            g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 20));
            //game over display
            restart.setVisible(true);
            restart.setFont(g2.getFont());

            quit.setVisible(true);
            quit.setFont(g2.getFont());
        }

        //TODO: draw all the obstacles.

    }

    public int getHit(){
        return hit;
    }


    public void levelUp(){
        timer.stop();

        if (level < 5) {
            level++;
            init(level, this.life.lifeCalc());
        } else {
            // end game here
        }
    }

    private static JFrame window;

    //sets ups the panel and frame.  Probably not much to modify here.
    public static void main(String[] args) {
        init(4, 3);
    }

    private static void init(int level, int lifeCount) {
        if (window != null) {
            window.dispose();
        }

        window = new JFrame("Frogger!");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setBounds(0, 0, FRAMEWIDTH, FRAMEHEIGHT + 22); //(x, y, w, h) 22 due to title bar.


        FroggerMain frogger = new FroggerMain(level, lifeCount);
        frogger.setSize(FRAMEWIDTH, FRAMEHEIGHT);

        frogger.setFocusable(true);
        frogger.grabFocus();

        window.add(frogger);
        window.setVisible(true);
        window.setResizable(false);
    }
}