/**
 * Created by student on 2/7/18.
 */
public class Log extends Sprite {

    private double dirmath;
    private int dir;

    public boolean getHasFrog() {
        return hasFrog;
    }

    public void setHasFrog(boolean hasFrog) {
        this.hasFrog = hasFrog;
    }

    private boolean hasFrog;

    public Log(int x, int y, int speed){
        super(x, y, EAST);

        this.setSpeed(speed);

        setPic("logMedium.png", EAST);
        dirmath = Math.random();
        if(dirmath < .5 ){
            dir = 0;
        }
        else
            dir = 180;
        setDir(dir);
    }

    @Override
    public void update(){
        super.update();
    }


}
