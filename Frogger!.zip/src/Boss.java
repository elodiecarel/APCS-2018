/**
 * Created by student on 2/11/18.
 */

import java.awt.*;
public class Boss extends Obstacle {

    private Frog frog;

    public boolean isTrackFrog() {
        return trackFrog;
    }

    public void setTrackFrog(boolean trackFrog) {
        this.trackFrog = trackFrog;
    }

    private boolean trackFrog;

    public Boss(int x, int y, Frog frog){
        super(x, y);

        setPic("Boss.png", EAST);
        this.frog = frog;
    }

    public Point track(){
        return frog.getCenterPoint();
    }

    @Override

    public void update() {

        if (!trackFrog) return;

        double xd = track().getX();
        double yd = track().getY();

        int x = (int)xd;
        int y = (int)yd;

        int xme = getLoc().x;
        int yme = getLoc().y;

        int xfin, yfin;

        if (x > xme) {
            xfin = 5;
        } else {
            xfin = -5;
        }

        if (y > yme) {
            yfin = 5;
        } else {
            yfin = -5;
        }

        getLoc().translate(xfin, yfin);
    }
}
