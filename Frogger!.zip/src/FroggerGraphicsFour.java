import javax.swing.*;
import java.awt.*;

/**
 * Created by student on 2/11/18.
 */
public class FroggerGraphicsFour extends JPanel{

    public static final int FW = 1000, FH = 600;

    public static void draw(Graphics2D g2){
        g2.setColor(new Color (28, 255, 143));
        g2.fillRect(0, 0, FW, FH);

        g2.setColor(Color.black);
        g2.setFont(new Font ("ArcadeClassic", Font.BOLD, 46));
        g2.drawString("It's very quiet... \n Almost a little TOO quiet...", 0, 300);


    }

}
