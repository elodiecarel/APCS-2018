/**
 * Created by student on 12/21/17.
 */
import java.awt.*;

/**
 * Created by michael_hopps on 9/26/17.
 */
public class Face {

    private int x, y, diameter, vx, vy;
    private Color color;

    public Face(int x, int y, int diameter, Color color){
        this.x = x;
        this.y = y;
        this.diameter = diameter;
        this.color = color;
        vx = (int)(Math.random()*31)-15;
        vy = (int)(Math.random()*31)-15;
    }
    public void draw(Graphics2D g2){
        //Big oval for head
        //2 smaller ovals for eyes
        //an arc for the smile

        g2.setColor(color);
        g2.fillOval(x, y, diameter, diameter);

        g2.setColor(Color.BLACK);
        g2.fillOval(x+diameter/4, y+diameter/4, diameter/6, diameter/6);
        g2.fillOval(x+diameter/4*3 - diameter/6, y+diameter/4, diameter/6, diameter/6);

        g2.drawArc(x+diameter/4, y+diameter/4, diameter/2, diameter/2, 200, 140);

    }

    public boolean contains(int x, int y){

        int r = diameter /2;
        int cx = this.x + r;
        int cy = this.y + r;
        int dx = cx - x;
        int dy = cy - y;
        double distance = Math.sqrt(dx*dx + dy*dy);
        if (distance > r)
            return false;
        else
            return true;
    }

    //w, h are width and height of the window.
    public void move(int w, int h) {
        x += vx;
        y += vy;

        if (y + diameter >= h) {
            vy = -Math.abs(vy);
            y = h - diameter;
        } else if (y <= 0) {
            vy = Math.abs(vy);
            y = 0;
        } else if (x + diameter >= w) {
            vx = -Math.abs(vx);
            x = w - diameter;
        } else if (x <= 0) {
            vx = Math.abs(vx);
            x = 0;
        }
    }

}