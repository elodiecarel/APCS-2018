/**
 * Created by student on 12/21/17.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/**
 * Created by michael_hopps on 12/21/17.
 */
public class FaceMain extends JPanel {

    private Timer timer;
    private ArrayList<Face> faces;

    public FaceMain(int w, int h) {
        setSize(w, h);

        faces = new ArrayList<Face>();
        // add 2 faces to the list
        Face one = new Face(100,100, 100, Color.blue);
        Face two = new Face(500, 200, 100, Color.yellow);
        faces.add(one);
        faces.add(two);

        setUpTimer(40);
        setUpMouseListener();
    }

    public void setUpTimer(int delay){
        if(timer == null) {
            timer = new Timer(delay, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    //this code executes each frame!
                    for (Face face: faces){
                        face.move(getWidth(), getHeight());
                    }


                    repaint();
                }
            });
        timer.start();
        }
    }

    public void setUpMouseListener(){
        addMouseListener(new MouseListener() {
            @Override
            public void mousePressed(MouseEvent e) {

                boolean faceRemoved = false;

                for (int i = 0; i < faces.size() ; i++) {
                    if(faces.get(i).contains(e.getX(), e.getY())){
                        faces.remove(i);
                        i--;
                        faceRemoved = true;
                    }
                }

                if(faceRemoved == false){

                int red = (int)(Math.random()*256);
                int blue = (int)(Math.random()*256);
                int green = (int)(Math.random()*256);

                Color color = new Color(red, green, blue);

                int diameter = 100;

                int x = e.getX() - diameter/2;
                int y = e.getY() - diameter/2;

                Face face = new Face(x, y, diameter, color);
                faces.add(0, face);


                repaint();
            }}
            @Override
            public void mouseClicked(MouseEvent e) {

            }
            @Override
            public void mouseReleased(MouseEvent e) {

            }
            @Override
            public void mouseEntered(MouseEvent e) {

            }
            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        // for each face in faces
        for (Face face: faces) {
            face.draw(g2);
        }
    }


    public static void main(String[] args) {
        JFrame frame = new JFrame("Faces!");
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        int width = 800;
        int height = 800;
        frame.setPreferredSize(new Dimension(width, height + 24));


        JPanel panel = new FaceMain(width, height);
        panel.setFocusable(true);
        panel.grabFocus();

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }

}