import java.util.ArrayList;

/**
 * Created by student on 12/20/17.
 */
public class Min {

    public static void main(String[] args) {

        ArrayList<Integer> nums = new ArrayList<Integer>();
        // the integer class is a "wrapper class."
        // it encasulates the primitive types in an object

        nums.add(12);
        nums.add(17);
        nums.add(40);
        System.out.println(nums);
        nums.add(1, 9001);
        System.out.println(nums);
        nums.set(3, 72);
        System.out.println(nums);

        // loop to remove all odd ints

        for (int i = 0; i < nums.size(); i++) {
            if (nums.get(i) % 2 == 1){
                nums.remove(i);
                i--;
            }
        }
        System.out.println(nums);
    }
}
