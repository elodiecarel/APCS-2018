package Faces;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/**
 * Created by michael_hopps on 12/21/17.
 */
public class FaceMain extends JPanel {

    private Timer timer;
    private ArrayList<Face> faces;

    public FaceMain(int w, int h) {
        setSize(w, h);

        faces = new ArrayList<Face>();

        setUpTimer(1000/60);
        setUpMouseListener();
    }

    public void setUpTimer(int delay){
        if(timer == null) {
            timer = new Timer(delay, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    //this code executes each frame!
                    for(Face face: faces)
                        face.move(getWidth(), getHeight());

                    repaint();
                }
            });
        }

        timer.start();
    }
    public void setUpMouseListener(){
        addMouseListener(new MouseListener() {
            @Override
            public void mousePressed(MouseEvent e) {

                boolean removedFace = false;
                for (int i = 0; i < faces.size(); i++) {
                    if(faces.get(i).contains(e.getX(), e.getY())){
                        faces.remove(i);
                        i--;
                        removedFace = true;
                    }
                }

                if(!removedFace) {
                    faces.add(new SquareFace(e.getX(), e.getY(), 200));
//                    if (Math.random() < .5) {// half the time face
//                    int diameter = (int) (Math.random() * 140) + 60;
//                    Face LMAO = new Face(e.getX() - diameter / 2, e.getY() - diameter / 2, diameter);
//                    faces.add(LMAO);
//                }
//                else{// other half, angry face
//                    AngryFace roar = new AngryFace(e.getX() - 40, e.getY() - 40 );
//                        faces.add(roar);
//                    }
                }
                System.out.println(faces.size());
                repaint();
            }
            @Override
            public void mouseClicked(MouseEvent e) {

            }
            @Override
            public void mouseReleased(MouseEvent e) {

            }
            @Override
            public void mouseEntered(MouseEvent e) {

            }
            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;

        for(Face temp: faces)
            temp.draw(g2);

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Polymorphic Faces!");
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        int width = 800;
        int height = 800;
        frame.setPreferredSize(new Dimension(width, height + 24));


        JPanel panel = new FaceMain(width, height);
        panel.setFocusable(true);
        panel.grabFocus();

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }

}
