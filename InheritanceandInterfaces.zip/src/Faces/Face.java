package Faces;

import java.awt.*;

// secretly, face is extending a class called object.
// if you don't extend another class, you are extending object
// Objects, are the most versatile variable type you can use
// equals(Object obj) -> compare memory addresses
// toString() -> SOUT(new Face()) (toString() will print the memory address)
// both can be overridden

public class Face {

    private int x, y, diameter, vx, vy;
    private Color color;

    public Face(int x, int y, int diameter){
        this.x = x;
        this.y = y;
        this.diameter = diameter;
        this.color = Color.YELLOW;
        vx = (int)(Math.random() * 31) - 15;
        vy = (int)(Math.random() * 31) - 15;
    }
    public void draw(Graphics2D g2){

        g2.setColor(color);
        g2.fillOval(x, y, diameter, diameter);

        g2.setColor(Color.BLACK);
        g2.fillOval(x+diameter/4, y+diameter/4, diameter/6, diameter/6);
        g2.fillOval(x+diameter/4*3 - diameter/6, y+diameter/4, diameter/6, diameter/6);

        g2.drawArc(x+diameter/4, y+diameter/4, diameter/2, diameter/2, 200, 140);

    }

    public boolean contains(int x, int y){
        int centerX = this.x + diameter/2;
        int centerY = this.y + diameter/2;

        int dx = x - centerX;
        int dy = y - centerY;
        double dist = Math.sqrt(dx*dx + dy*dy);

        if(dist < diameter/2)
            return true;
        else
            return false;
    }

    //w, h are width and height of the window.
    public void move(int w, int h) {
        x += vx;
        y += vy;

        if (y + diameter >= h) {
            vy = -Math.abs(vy);
            y = h - diameter;
        } else if (y <= 0) {
            vy = Math.abs(vy);
            y = 0;
        } else if (x + diameter >= w) {
            vx = -Math.abs(vx);
            x = w - diameter;
        } else if (x <= 0) {
            vx = Math.abs(vx);
            x = 0;
        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getDiameter() {
        return diameter;
    }

    public void setDiameter(int diameter) {
        this.diameter = diameter;
    }

    public int getVx() {
        return vx;
    }

    public void setVx(int vx) {
        this.vx = vx;
    }

    public int getVy() {
        return vy;
    }

    public void setVy(int vy) {
        this.vy = vy;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
