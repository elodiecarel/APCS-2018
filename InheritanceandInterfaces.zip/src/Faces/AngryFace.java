package Faces;

import java.awt.*;

/**
 * Created by michael_hopps on 1/9/18.
 */
public class AngryFace extends Face{

    public AngryFace(int x, int y){
        super(x, y, 80);

        setColor(Color.RED);
    }

    // override the draw method

    @Override
    public void draw(Graphics2D g2) {
        g2.setColor(getColor());
        g2.fillOval(getX(), getY(), getDiameter(), getDiameter());

        g2.setColor(Color.BLACK);
        g2.fillOval(getX()+getDiameter()/4, getY()+getDiameter()/4, getDiameter()/6, getDiameter()/6);
        g2.fillOval(getX()+getDiameter()/4*3 - getDiameter()/6, getY()+getDiameter()/4, getDiameter()/6, getDiameter()/6);

        g2.drawArc(getX()+getDiameter()/4, getY()+getDiameter()/2, getDiameter()/2, getDiameter()/2, 20, 140);
        g2.setStroke(new BasicStroke(5));
        g2.drawLine(getX()+getDiameter()/4, getY()+getDiameter()/6, getX()+getDiameter()/4+getDiameter()/6, getY()+getDiameter()/4);
        g2.drawLine(getX()+getDiameter()/4*3 - getDiameter()/6, getY()+getDiameter()/4, getX()+getDiameter()/4*3 , getY()+getDiameter()/6);
        g2.setStroke(new BasicStroke(1));
    }

    @Override
    public void move(int w, int h){
        setVx((int)(Math.random()*20-10));
        setVy((int)(Math.random()*20-10));
        super.move(w, h);
    }
}
