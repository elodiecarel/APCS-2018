package Faces;

import Notfaces.Square;

import java.awt.*;

/**
 * Created by student on 1/10/18.
 */
public class SquareFace extends Face{

    private int lengthsofar;
    private int sidelength;
    private int dir;

    public SquareFace(int x, int y, int sidelength){
        super(x, y, 100);

        this.sidelength = sidelength;
        dir = 0;
        setVx(5);
        setVy(0);

        this.sidelength = sidelength;


        setColor(Color.green);
    }


    @Override
    public void move(int w, int h){
        lengthsofar += Math.abs(getVx());
        lengthsofar += Math.abs(getVy());

        if(Math.abs(lengthsofar) > sidelength){
            dir = dir + 1;
            dir = dir % 4;

            if(dir == 0){
                setVx(5);
                setVy(0);

            } else if(dir ==1){
                setVx(0);
                setVy(5);

            } else if(dir == 2){
                setVx(-5);
                setVy(0);

            } else if(dir == 3){
                setVx(0);
                setVy(-5);
            }

            lengthsofar = 0;
        }

        super.move(w,h);

    }
}
