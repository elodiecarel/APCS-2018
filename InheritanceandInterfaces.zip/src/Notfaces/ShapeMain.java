package Notfaces;

/**
 * Created by student on 1/8/18.
 */
public class ShapeMain {
    public static void main(String[] args) {

        Rectangle myRect = new Rectangle(3,8);
        System.out.println(myRect.getArea());

        Square mySquare = new Square(4);
        System.out.println(mySquare.getArea());

        myRect = mySquare; // GOOD, ALWAYS true.

        mySquare = ((Square)myRect);
        // casts it to be a square

        // mySauare = myRect; // BAD, not always true.

        // RECTangle can't print stuff before you cast it to a square.

        // hw is 9.1
    }
}
