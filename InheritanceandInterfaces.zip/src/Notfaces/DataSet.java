package Notfaces;

import java.util.ArrayList;

/**
 * Created by michael_hopps on 1/3/18.
 */
public class DataSet {

    private ArrayList<Quantifiable> set;

    public DataSet(){
        set = new ArrayList<>();
    }

    public void add(Quantifiable newItem){
        set.add(newItem);
    }

    public double getMean(){

        double sum = 0;
        for(Quantifiable thing : set){
            sum += thing.getValue();
        }
        return sum / set.size();
    }

    public Quantifiable getMaxItem(){

        return null;
    }

    public Quantifiable getMaxValue(){

        return null;
    }



}
