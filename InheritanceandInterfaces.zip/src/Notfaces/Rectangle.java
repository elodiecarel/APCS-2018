package Notfaces;

/**
 * Created by student on 1/8/18.
 */
/*
Inheritance
   when you write a class you can choose to have that class inherit from another class (extends)
   creates a parent / child relationship (super / sub) (you write sub ) ( existing class is super)

   it does not effect the parent class at all
   gains access to every instance field, method, whatever to the parent class.

   .getwidth() and .paintComponent(Graphics) are inherited from JPanel
   subclass is now a member of the superclass group


* */
public class Rectangle {
    double b;
    double h;

    public Rectangle(double b, double h){
        this.b = b;
        this.h = h;
    }

    public double getArea(){
        double area;
        area = b*h;

        return area;
    }

}
