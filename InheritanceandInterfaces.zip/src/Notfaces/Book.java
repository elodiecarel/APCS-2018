package Notfaces;

/**
 * Created by michael_hopps on 1/3/18.
 */

/*
both are the same basic idea
allow us to...
    1. group different classes together based on some commonality
    2. write generic code (code that will work with more than one type of object, or work
       differently based on the type of object.) code is more flexible
    Interfaces
    1. they're not a class- only thing in java that is not
    2. they have weaker versions of methods. all they do is declare methods. they don't define them.
    3. classes can implement an interface and that allows objects of that class to be a member of
       that interface group.
    4.
 */
public class Book implements Quantifiable{

    private int numPages;
    private String title;

    public Book(int numPages, String title) {
        this.numPages = numPages;
        this.title = title;
    }

    @Override
    public double getValue() {
        return numPages;
    }

    public String getTitle(){return title;}
}
