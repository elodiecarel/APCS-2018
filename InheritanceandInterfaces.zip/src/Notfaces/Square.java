package Notfaces;

/**
 * Created by student on 1/8/18.
 */
public class Square extends Rectangle{

    public Square(double s){
        super(s, s);
        // accessing the parent contructor with super. have to do that first.
        // it has to be the first line of the constructor or it doesn't work
    }

    public void printStuff(){
        System.out.println("STUFF");
    }
}
