package Notfaces;

/**
 * Created by michael_hopps on 1/3/18.
 */
public interface Quantifiable {

    double getValue();

}
