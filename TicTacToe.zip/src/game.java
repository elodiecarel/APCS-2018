import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

/**
 * Created by student on 11/16/17.
 */
public class game {

    private int[][] gr;
    private int clickcounter;

    public game(){
        gr = new int[3][3];
        clickcounter = 0;
    }
    public void draw(Graphics2D g2, int w, int h) {

        g2.setStroke(new BasicStroke(8));

        for (int r = 0; r <gr.length ; r++) {
            for (int c = 0; c <gr[0].length ; c++) {
                g2.drawRect(c*w, r*h, w, h);
            }
        }
        for (int r = 0; r < gr.length; r++) {

            for (int c = 0; c < gr[0].length; c++) {
                if (gr[r][c] == 0) {
                    g2.drawRect(c * w, r * h, w, h);

                } else if(gr[r][c] == 1)
                    g2.drawOval(c * w, r * h, w, h);
                else if(gr[r][c] == 2){
                    g2.drawLine(c*w , r* h, c*w + w , r*h + w);
                    g2.drawLine(c*w  + w, r*h , c*w , r*h + w );
                }
            }

        }

        g2.setColor(Color.red);
        Font font = new Font("Sans Serif", Font.BOLD, 30);
        g2.setFont(font);
        if (didWin() == 1){
            g2.drawString("Player one wins! \n Click anywhere to play again", w/8, h+ h/2);
        }
        if (didWin() == 2)
            g2.drawString("Player two wins! \n Click to play again", w/8, h+ h/2);

        else
            g2.drawString("", 0,0);
    }


    public void processClick(int r, int c){

        if (gr[r][c] == 0 && clickcounter % 2 == 0) {
            gr[r][c] = 1;
            clickcounter++;

        } else if(gr[r][c] == 0 && clickcounter % 2 == 1) {
            gr[r][c] = 2;
            clickcounter++;
        }
    }

    public int didWin(){
        // plug in 8 scenarios

                if(gr[0][0] == gr[0][1] && gr[0][1] == gr[0][2] && gr[0][1] != 0)
                    return gr[0][0];
                else if(gr[1][0] == gr[1][1] && gr[1][1] == gr[1][2] && gr[1][0] != 0)
                    return gr[1][0];
                else if(gr[2][0] == gr[2][1] && gr[2][1] == gr[2][2] && gr[2][0] != 0)
                    return gr[2][0];


                else if(gr[0][0] == gr[1][0] && gr[1][0] == gr[2][0] && gr[0][0] != 0)
                    return gr[0][0];
                else  if(gr[0][1] == gr[1][1] && gr[1][1] == gr[2][1] && gr[2][1] != 0)
                    return gr[0][1];
                else if(gr[0][2] == gr[1][2] && gr[1][2] == gr[2][2] && gr[2][2] != 0)
                    return gr[2][0];

                else if(gr[0][0] == gr[1][1] && gr[1][1] == gr[2][2] && gr[0][0] != 0)
                    return gr[0][0];
                else if(gr[0][2] == gr[1][1] && gr[1][1] == gr[2][0] && gr[2][0] != 0)
                    return gr[2][0];

      else
          return 0;
    }

    public void endGame(){
        if (didWin()== 1 || didWin() ==2) {

        }
    }
}

