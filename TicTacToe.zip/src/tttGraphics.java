import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Created by student on 11/16/17.
 */
public class tttGraphics extends JPanel {

    /**
     * Created by michael_hopps on 11/14/17.
     */

        private game ttt;

        public tttGraphics(int w, int h) {
            setSize(w, h);

//            gr = new int[3][3];
            ttt = new game();

            addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {

                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (ttt.didWin() == 1 || ttt.didWin() == 2) {
                        startGame();
                        return;
                    }

                    int x = e.getX();
                    int y = e.getY();

                    int w = getWidth() / 3;
                    int h = getHeight() / 3;

                    int r = y / h;
                    int c = x / w;

                    ttt.processClick(r,c);
                    repaint();
                }


                @Override
                public void mouseReleased(MouseEvent e) {

                }

                @Override
                public void mouseEntered(MouseEvent e) {

                }

                @Override
                public void mouseExited(MouseEvent e) {

                }

            });
        }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        int w = getWidth() / 3;
        int h = getHeight() / 3;
        ttt.draw(g2, w, h);
    }


        // static: method is not in the object it's in the class
        // outside of the object system- no order

    public static JFrame frame;

        public static void main(String[] args) {
            startGame();
        }

        public static void startGame() {
            if (frame != null) {
                frame.dispose();
            }

            frame = new JFrame("Tic Tac Toe");
            frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
            int width = 800;
            int height = 800;
            frame.setPreferredSize(new Dimension(width, height + 24));


            JPanel panel = new tttGraphics(width, height);
            panel.setFocusable(true);
            panel.grabFocus();

            frame.add(panel);
            frame.pack();
            frame.setVisible(true);
        }
}




