
    /**
     * Created by michael_hopps on 10/25/17.
     */
    public class WednesdayMain {

        public static void main(String[] args) {

            int[] intTest = {7, 4, 1, 3, 0, 1, 10, 5, 8};
            String[] strTest = {"Computer", "science", "for", "life", "#java", "#hashtag"};


            WednesdayPractice obj = new WednesdayPractice();
        System.out.println(obj.totalChars(strTest)); //should be 35

        System.out.println(obj.average(intTest));

        System.out.println(obj.indexOfShortestString(strTest));

        obj.replace(intTest, 1, 4);
        obj.printArray(intTest);
        }


    }

