import java.util.Arrays;

/**
 * Created by student on 10/20/17.
 */
public class ArraysMainOne {
    public static void main(String[] args) {

        int[] nums = new int[10]; // indexed 0-9
        // nums currently contains 10 0's
        // modify nums to contain 0,5, 10, 15... 45

        for (int i = 0; i < nums.length; i++) {
            // traversing an array... accesssing every single index in an array
            nums [i] = i*5;
        }
// for(int bob: nums){code goes here)
        ArrayOperations thing = new ArrayOperations(nums);
        System.out.println(thing.getSum());
        System.out.println(thing.countEvens());

// can't print an array using sout
        // the memory address of where the array is stored on the computer
        // because it's an object like a house. if you tried to print a house... it wouldn't work
        System.out.println(nums);

//        for (int i = 0; i < nums.length; i++) {
//
//            System.out.print(nums[i] + ", ");
//        }
//
//        for(int n: nums){
////          for each loops. "for each integer n in nums...
//            System.out.print(n  + ", ");
//        }

        System.out.println(Arrays.toString(nums));
    }
}
