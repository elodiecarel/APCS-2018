/**
 * Created by student on 10/20/17.
 */
import java.util.Arrays;
public class ArrayOperations {

    private int[] arr;

    public ArrayOperations(int[] arr) {
        this.arr = arr;
        Arrays.sort(this.arr);
    }

    // reuturns the sum of the elements
    public int getSum() {

        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum = sum + arr[i];
        }
        return sum;
    }

    // for(int n: arr){if(n%2 ==0) count++}
    // returns the number of even ellements in array arr.
    public int countEvens() {
        int count = 0;

        for (int i = 0; i < arr.length; i++) {

            if (arr[i] % 2 == 0) {
                count++;
            }
        }
        return count;
    }

    public int getMaxValue(){
        int max = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if(arr[i]>max)
                max = arr[i];
            // maximum value
        }
        return max;
        // don't return inside a forloop because it wont finish
    }
}




//    // returns the average of the elements.
//    public double getMean() {
//
//    }
//
//    public int getMedian(){
//
//    }
//
//    // returns the distance from the smallest to largest element
//    public int range(){
//
//    }
//
//

