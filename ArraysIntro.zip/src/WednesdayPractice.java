import java.util.Arrays;

/**
 * Created by michael_hopps on 10/25/17.
 */
public class WednesdayPractice {


    /*
    Returns the total number of characters contained in
    all of the strings in strs.
     */
    public int totalChars(String[] strs){
    int chrs= 0;
        for (int i = 0; i <strs.length ; i++) {
            chrs = strs[i].length()+chrs;

        }
        return chrs;
    }

    /*
    Returns the arithmetic mean of the values in nums.
    Note that this returns a double, so it should include any decimals.
     */
    public double average(int[] nums){
        double sum= 0;
        for (int i = 0; i < nums.length; i++) {
            sum = sum + nums[i];
        }
        double avg = sum/nums.length;
        return  avg;

    }

    /*
    Returns the index of the string with the fewest characters
    in strs.
     */
    public int indexOfShortestString(String[] strs){
        int min = strs[0].length();
        for (int i = 0; i < strs.length; i++) {
            if(strs[i].length() < min){
                min = strs[i].length();
            }
        }
        return min;
    }


    /*
    This method replaces all instances of oldValue with newValue.
     */
    public void replace(int[] arr, int oldValue, int newValue){
        int j = oldValue;
        for (int i = 0; i < arr.length; i++) {
           oldValue = newValue;
            arr[j] = newValue;
        }
    }

    //These print methods are provided for printing arrays.
    public void printArray(int[] arr){
        System.out.println(Arrays.toString(arr));
    }
    public void printArray(String[] strs){
        System.out.println(Arrays.toString(strs));
    }

}