import com.sun.tools.doclets.internal.toolkit.util.SourceToHTMLConverter;

/**
 * Created by student on 9/13/17.
 */
public class Rectangle {

    private double length;
    private double width;

    public Rectangle (double length, double width){

        this.length=length;
        this.width=width;
    }
    // constructor is always the name of the class
    public Rectangle (double x1, double y1, double x2, double y2){

        // double return type
        // can't add void to void

        double length = Math.abs(x2-x1);
        double width = Math.abs(y2-y1);
        this.width= width;
        this.length= length;
    }

    public void printArea() {

        double area = length * width;
        System.out.println(area);
    }

        // make method that returns area, not just print it.
        // for returing area follow steps below.

        public double getArea(){
            double area = length*width;
        return area;
    }

}
