import com.sun.tools.doclets.internal.toolkit.util.SourceToHTMLConverter;

/**
 * Created by student on 9/8/17.
 */
public class Person {

    // instance fields go first- modeling variables
    // instance fields- private type name;
    // declaring the instance field- the value will come later

    private int age; // public- can be accessed from outside class. private- cannot be accessed from outside the class
    private String name;

    // constructor- how to build one of these Person things
    // job: make sure all instance field have a value

    public Person(String name, int age){
       this.name = name;
        this.age = age;
        // this says look in this class for an instance field called "...."

        // methods- actions a person can perform
    }

    public void sayHello(){
        System.out.println(" Hi! My name is " + name + ", and I'm " + age + " years old");

    }

    public void haveBirthday (){
        age= age +1;
//        age += 1;
//        age ++;
    }

}
