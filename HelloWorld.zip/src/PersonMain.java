/**
 * Created by student on 9/8/17.
 */
public class PersonMain {
    public static void main(String[] args) {
        // classes: two types
            // one with a main (runable independantly) and all others without (not runnable independantly)
            // without a main used to model some entity
            // 3 components
                // instance fields- major modeling variables
                    // x and y instance fields for alien position, an instance field for it's image
                // methods- actions model can perform ex: model for move in space invaders... the main is a method, but there's others too
                // constructor- how we make an object from the model
        // object- actualy usable instance of a class
        // when you see the word new, it activates a constructor which builds the object
        // objects are seperate entities if you type "new"

        Person me = new Person("Elodie", 17);
                me.sayHello();
        me.haveBirthday();

        Person muntasir = new Person ("Muntasir", 17);
                muntasir.sayHello();


    }

}
