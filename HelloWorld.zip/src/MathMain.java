import com.sun.tools.doclets.internal.toolkit.util.SourceToHTMLConverter;

/**
 * Created by student on 9/12/17.
 */
public class MathMain {
    public static void main(String[] args) {
        Cylinder can = new Cylinder (4,2);
        Cylinder three = new Cylinder (3, 6);
        Cylinder two = new Cylinder (1.5, 3);

        can.printVolume();
        three.printVolume();
        two.printVolume();


        Rectangle rect1 = new Rectangle (400,100,200,50);
        Rectangle rect2 = new Rectangle(30, 100);

        double sumArea = rect1.getArea() + rect2.getArea();
        System.out.println(sumArea);

       rect1.printArea();
       rect2.printArea();
    }

    }

