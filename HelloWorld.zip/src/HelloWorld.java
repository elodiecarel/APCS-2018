/**
 * Created by student on 9/5/17.
 */
public class HelloWorld {


    // main method - all executed code goes in here!
    // shortcut: psvm TAB
    public static void main(String[] args) {
        System.out.println("Hello World!"); // sout TAB

        int age = 17;
        System.out.println(age);
        int heightInches;
        heightInches = 54;
        System.out.println(heightInches);
                // happy birthday! one year older!
        age = age + 1; // can only go right to left. puts right side of equation on left
        // age + 1 - age: NOPE
        System.out.println(age);

        double price = 19.99;
        System.out.println(price);
        // change price to reflect the 6.25% MA sales tax
        price = price * 1.0625;
        System.out.println(price);
        // can't go from ints to doubles [age = price] is wrong
        // can go from doubles to ints
        price = age;
        System.out.println(price);

    }


}
