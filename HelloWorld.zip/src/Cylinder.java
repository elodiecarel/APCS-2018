/**
 * Created by student on 9/12/17.
 */
public class Cylinder {
    private double radius;
    private double height;

    public Cylinder (double radius, double height){
        this.radius = radius;
        this.height= height;
    }
    public void printVolume(){
        double volume = Math.PI*radius*radius*height;
        System.out.println(volume);
    }

    public void scaleBy(double factor) {
       height = height * factor;
        radius *= factor;

    }

}
