/**
 * Created by student on 11/30/17.
 */


// Checklist before turning in
//         1. Jslider and button functionality and aesthetic
//            a. get Jslider assigned to the speed
//            b. get Button to work without having to click
//            c. Move both into the menu with a written description
//

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;

public class LifePanel extends JPanel {

    private Cell[][] grid;
    private Timer timer;
    private int size;


    public LifePanel(int w, int h) {
        setSize(w, h);
        this.size = 20;
        grid = new Cell[this.size][this.size];
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                grid[r][c] = new Cell(r, c, grid, 40);
            }
        }

        grid[4][3].spawn(); //for testing
        grid[4][4].spawn();
        grid[4][5].spawn();
        grid[3][5].spawn();
        grid[2][4].spawn();

        //System.out.println(grid[5][2].numNeigh(grid));

//        Cell[] cellsToSpawn = new Cell[grid.length * grid[0].length];
//        Cell[] cellsToMurder = new Cell[grid.length * grid[0].length];

        JSlider speed = new JSlider(50, 1000);
        speed.setValue(250);
        // how to make the delay change with the jslider?
        // timer.setdelay
        add(speed);
        speed.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                timer.setDelay(speed.getMaximum() - speed.getValue());
            }
        });

        this.timer = new Timer(speed.getValue(), new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int cellToSpawnCount = 0;
                int cellToMurderCount = 0;
                Cell[] cellsToSpawn = new Cell[grid.length * grid[0].length];
                Cell[] cellsToMurder = new Cell[grid.length * grid[0].length];
                for (int r = 0; r < grid.length; r++) {
                    for (int c = 0; c < grid[0].length; c++) {

                        int numNeigh = grid[r][c].numNeigh(grid);

                        if (numNeigh == 3) {
                            cellsToSpawn[cellToSpawnCount] = grid[r][c];
                            cellToSpawnCount++;
                        }

                        if (numNeigh >= 4) {
                            cellsToMurder[cellToMurderCount] = grid[r][c];
                            cellToMurderCount++;
                        }

                        if (numNeigh <= 1) {
                            cellsToMurder[cellToMurderCount] = grid[r][c];
                            cellToMurderCount++;
                        }
                    }
                }

                for (int idx = 0; idx < cellToSpawnCount; idx++) {
                    cellsToSpawn[idx].spawn();
                }

                for (int idx = 0; idx < cellToMurderCount; idx++) {
                    cellsToMurder[idx].murder();
                }

                repaint();
            }
        });
        addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {

                int x = e.getX();
                int y = e.getY();

                int w = 40;
                int h = 40;

                int r = y / h;
                int c = x / w;

                grid[r][c].processClick(r, c);

                repaint();

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });


        timer.start();


        // this button will create a exploder thingy
        JButton button = new JButton("Exploder");

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                grid[10][10].spawn();
                grid[11][10].spawn();
                grid[12][10].spawn();
                grid[13][10].spawn();
                grid[14][10].spawn();

                grid[10][12].spawn();
                grid[14][12].spawn();

                grid[10][14].spawn();
                grid[11][14].spawn();
                grid[12][14].spawn();
                grid[13][14].spawn();
                grid[14][14].spawn();


                grabFocus();
            }
        });

        //this.setLayout(null);
        add(button);
        button.setLocation(830, 200);

        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {

                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    if (timer.isRunning())
                        timer.stop();

                    else
                        timer.start();
                }
                if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
                    for (int r = 0; r < grid.length; r++) {
                        for (int c = 0; c < grid[0].length; c++) {
                                grid[r][c].murder();
                        }
                    }

                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                grid[r][c].draw(g2);
            }
        }

        Menu menu = new Menu();
        menu.draw(g2, getWidth(), getHeight());
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Grid Graphics");
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        int width = 1200;
        int height = 800;
        frame.setPreferredSize(new Dimension(width, height + 24));

        JPanel panel = new LifePanel(width, height);
        panel.setFocusable(true);
        panel.grabFocus();

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);

    }


}


