/**
 * Created by student on 12/5/17.
 */
import javax.swing.plaf.basic.BasicColorChooserUI;
import java.awt.*;

public class Menu {

    public void draw(Graphics2D g2, int width, int height){

        Font f = new Font("comic sans ms", Font.PLAIN, 50);
        g2.setFont(f);
        g2.drawString("Instructions", 850, 50);

        Font g = new Font("comic sans ms", Font.PLAIN, 15);
        g2.setFont(g);
        g2.drawString("Press the space bar to start and stop the timer", 830, 100);
        g2.drawString("Press the delete key to clear the board", 830, 150);
        g2.drawString("Click on a square to spawn or murder it", 830, 200);
        g2.drawString("Move the slider to change the speed", 830, 250);
        g2.drawString("Click the Explode button to make a cool pattern!", 830, 300);


    }
}
