import javax.swing.*;
import java.awt.*;

/**
 * Created by student on 11/29/17.
 */
public class Cell {

    private boolean isAlive;
    private int row, col;
    private Cell[][] grid;
    private int size;
    private int clickcounter;
    private int age;


    public Cell(int r, int c, Cell[][] grid, int size) {
        isAlive = false;
        row = r;
        col = c;
        this.grid = grid;
        this.size = size;
        age = 0;
    }

    // this isn't quite right because this will return the number of all alive cells.
    public int numNeigh(Cell[][] grid) {
        int n = 0;

        if (row - 1 > -1 && col + 1 < grid[0].length && grid[row - 1][col + 1].isAlive) {
            n++;
        }
        if (row - 1 > -1 && col < grid[0].length && grid[row - 1][col].isAlive) {
            n++;
        }
        if (row - 1 > -1 && col > 0 && grid[row - 1][col - 1].isAlive) {
            n++;
        }


        if (row > -1 && col - 1 > -1 && grid[row][col - 1].isAlive) {
            n++;
        }
        if (row > -1 && col + 1 < grid[0].length && grid[row][col + 1].isAlive) {
            n++;
        }


        if (row + 1 < grid.length && col - 1 > -1 && grid[row + 1][col - 1].isAlive) {
            n++;
        }
        if (row + 1 < grid.length && col < grid[0].length && grid[row + 1][col].isAlive) {
            n++;
        }
        if (row + 1 < grid.length && col + 1 < grid[0].length && grid[row + 1][col + 1].isAlive) {
            n++;
        }
        return n;
    }

    public void murder() {
        isAlive = false;
    }

    public void spawn() {
        isAlive = true;
        age ++;
    }

    public boolean isAlive() {
        return isAlive;
    }

    public void draw(Graphics2D g2) {
        if (isAlive) {
//            g2.fillRect(col * size, row * size, size, size);


            if (age <= 1) {
                g2.setColor(new Color(35, 255, 174));
                g2.fillRect(col * size, row * size, size, size);
            }
            if (age == 2) {
                g2.setColor(new Color(33, 218, 147));
                g2.fillRect(col * size, row * size, size, size);
            }
            if (age == 3) {
                g2.setColor(new Color(31, 184, 131));
                g2.fillRect(col * size, row * size, size, size);
            }
            if (age == 4) {
                g2.setColor(new Color(21, 125, 86));
                g2.fillRect(col * size, row * size, size, size);
            }
            if (age == 5) {
                g2.setColor(new Color(11, 83, 58));
                g2.fillRect(col * size, row * size, size, size);
            }
            if (age >= 6) {
                g2.setColor(new Color(0, 0, 0));
                g2.fillRect(col * size, row * size, size, size);
            }
        }

        if (isAlive== false) {
            g2.setColor(Color.white);
            g2.fillRect(col * size, row * size, size, size);
        }

        g2.setColor(Color.black);
        g2.drawRect(col * size, row * size, size, size);
    }
    public void processClick(int r, int c){
                if (grid[r][c].isAlive() == true)
                    grid[r][c].murder();

                else if (grid[r][c].isAlive() == false) {
                    grid[r][c].spawn();
                    age = 1;
                }
            }


    }

// set layout and bounds for jbutton repaint