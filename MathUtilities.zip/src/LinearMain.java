import javax.sound.sampled.Line;

/**
 * Created by student on 9/19/17.
 */
public class LinearMain {

    public static void main(String[] args) {

       LinearFunction line1 = new LinearFunction(2, 3);
        LinearFunction line2 = new LinearFunction(1, 1, 2, 5);

        line1.printIntersection(line2);

        int a = 5;
        int b = 12;
        int c = b/a;
        b = b-4;
        a = a +2*3 -9/10;

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }

}
