/**
 * Created by student on 9/19/17.
 */
public class LinearFunction {

    private double m;
    private double b;

    public LinearFunction(double m, double y_int) {
        this.m = m;
        this.b = b;
    }

    public LinearFunction(double x1, double y1, double x2, double y2) {
        m = (y2 - y1) / (x2 - x1);
        b = y1 - (m) * (x1);
    }

    public double getY(double x) {
        double y = m * x + b;
        return y;
    }

    public double getX(double y) {
        double x = (y - b) / m;
        return x;
    }

    public double getSlope() {
        return m;
    }

    public double getYInt() {
        return b;
    }

    public void printThreePoints(double startX, double dx) {
        double a = getY(startX);
        double b = getY(startX + dx);
        double c = getY(startX + dx + dx);
        System.out.println(startX + a);
        System.out.println(startX + dx + b);
        System.out.println(startX + dx * 2 + c);
    }

    public void printIntersection(LinearFunction other) {
      if (Math.abs(m - other.getSlope())<.000000001){
          if (b == other.getYInt()) {

              System.out.println("There are infinite intersections.");
          }}

            else{
                System.out.println("There are no intersections.");
        }

        double top = other.getYInt() - this.getYInt();
        double bottom = getSlope() - other.getSlope();
        double x = top / bottom;
        double y = getY(x);
        System.out.println("(" + x + ", " + y + ")");
    }

}
