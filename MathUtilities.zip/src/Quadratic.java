import javax.naming.NameNotFoundException;

/**
 * Created by student on 9/14/17.
 */
public class Quadratic {
    private double a;
    private double b;
    private double c;

    public Quadratic(double a, double b, double c){
        this.a=a;
        this.b=b;
        this.c=c;
    }
    // Math.sqrt
    public double getRootA(){
        double rootsA= (-b+Math.sqrt(b*b-4*a*c))/(2*a);
        return rootsA; // returns end your method!

    }

    public double getRootB(){
        double rootsB= (-b-Math.sqrt(b*b-4*a*c))/(2*a);
        return rootsB;

    }

    // prints the roots in the format: x=5, -2,67
    // if there are no roots, prints: "No solution"

    public void printRoots(){
        if(b*b-4*a*c<0)
            System.out.println("No solution");

       else {
           System.out.println("x= " + getRootA() + ", " + getRootB());
            }
    }

    public double getY(double x){
        double y=a*x*x+b*x+c;
        return y;
    }

    public double getVertexX(){
        double x = -b/(2*a);
        return x;
    }

    public double getVertexY(){
        double x = getVertexX();
        double y = getY(x);
        return y;
    }
}
