import com.sun.tools.doclets.internal.toolkit.util.SourceToHTMLConverter;

/**
 * Created by student on 9/14/17.
 */
public class MathMain {

    public static void main(String[] args) {

       Quadratic func = new Quadratic(1, 2, -3);
        double ans1 = func.getRootA();
        double ans2 = func.getRootB();

        System.out.println(ans1 + ", " + ans2);

        double ans3 = func.getY(3);
        System.out.println(ans3);

        double ans4 = func.getVertexX();

        double ans5 = func.getVertexY();

        System.out.println("The vertex is " + "("+ ans4 + ", " + ans5 +")");

    }

}
