/**
 * Created by student on 11/13/17.
 */
public class TwoDIntroMain {

    public static void main(String[] args) {

        int[][] grid = new int[3][3]; // 3 rows, 3 columns. 3 arrays w/ 3 elements each

        // want grid.length, because it gives us the # of rows // number of 1D arrays
        // grid[0].length, num of cols // length of the 0ith 1D array
        // this is called ROW MAJOR order - go across first row, then next row, then so on...

        int num = 2;

        for (int r = 0; r < grid.length ; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                grid[r][c] = num;
                num  += 2;

            }
        }
// print the 2D array
        for (int r = 0; r < grid.length ; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                System.out.print(grid[r][c] + "\t");
            }
            System.out.println();
        }

    }
}

// 2 dimensional arrays
    // grid of numbers vs list... looks like a matrix
    // an array of arrays!
    // int [][] grid
    // [[2 4 6]
    // [8, 10, 12]
    // [14, 16, 18]]
    // grid [0]... 0ith element is the first array... in Hopp's ex: [2,4,6]
    // grid [0][1] will give element 4 in Hopp's ex
    // row, column