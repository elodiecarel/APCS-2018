/**
 * Created by student on 11/14/17.
 */
/**
 * Created by michael_hopps on 11/14/17.
 */
public class PracticeProblems {

    public static void main(String[] args) {

        String[][] grid = new String [4][5];

        for (int r = 0; r < grid.length ; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                if (c % 2 == 0)
                grid[r][c] = "y";

                else
                    grid[r][c] = "x";

            }
        }

        int[][] gr = new int [4][6];
        int a = 0;

        for (int r = 0; r < gr.length; r++) {
            a = a + 1;

            for (int c = 0; c <gr[0].length; c++) {
                gr[r][c] = a;

            }

        }
        //1. Write a code segment to create a 2D array of Strings that...
        //has 4 rows and 5 columns.  The odd columns contain "x",
        //the even columns contain "y".

        //2. Write a code segment to create a 2D array of ints that has 4 rows and 6 columns.
        // It looks like this
        /*
        111111
        222222
        333333
        444444
         */

        printArray(grid);
        System.out.println("\n");
        printArray(gr);
    }




    public static void printArray(int[][] grid){
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                System.out.print(grid[r][c] + "\t\t");
            }
            System.out.println();
        }
    }

    public static void printArray(String [][] grid){
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                System.out.print(grid[r][c] + "\t\t");
            }
            System.out.println();
        }
    }

}
