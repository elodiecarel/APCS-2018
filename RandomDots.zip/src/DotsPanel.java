import javax.swing.*;
import java.awt.*;

/**
 * Created by Elodie Carel on 10/2/17.
 */
public class DotsPanel extends JPanel{

    private Dot a, b, c, d, e, f;

    public DotsPanel(int width, int height){
        setSize(width,height);

        a = new Dot(getWidth()/4, 0);
        b = new Dot(getWidth()/4,getHeight());
        c = new Dot(getWidth()/(8/4)+200,getHeight());
        d = new Dot(getWidth(), getHeight()/2);
        e = new Dot(0,getWidth()/2);
        f = new Dot(getWidth()/2+200,0);
        //3.  Initialize Dot a to be the top center of the screen.
//            Initialize Dot b to be the bottom left of the screen.
//            Initialize Dot c to be the bottom right of the screen.

    }

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;


        Dot currentDot = new Dot(getWidth()/2, getHeight()/2);


    g2.setStroke(new BasicStroke(5));

for (int i = 0; i < 100000; i++) {
        int rand = (int)(Math.random()*6);

    { if (rand ==0) currentDot = currentDot.getMidpoint(a);
        g2.setColor(new Color (32, 255, 14));
            currentDot.draw(g2);

            if (rand == 1)
                currentDot = currentDot.getMidpoint(b);
                g2.setColor(new Color(151, 0, 255));
                currentDot.draw(g2);

                if (rand == 2)
                currentDot = currentDot.getMidpoint(c);
                g2.setColor(new Color(255, 0, 229));
                    currentDot.draw(g2);

                if (rand == 3)
                    currentDot = currentDot.getMidpoint(d);
                    g2.setColor(new Color(1,1,1));
                    currentDot.draw(g2);


                if (rand ==4)
                    currentDot = currentDot.getMidpoint(e);
                   g2.setColor(new Color(0, 20, 255));
                    currentDot.draw(g2);

                if (rand ==5)
                    currentDot = currentDot.getMidpoint(f);
                    g2.setColor(new Color(255, 118, 86));
    }

        }
        }}



        //1.  Go finish the Dot class.
        //2.  Make a few Dots and their midpoints and draw them to test your work.
        //      Once satisfied with your results, delete your test code.
            //Dot test1 = new Dot(100, 100);
            //test1.draw(g2);
            //Dot test2...
            //Dot mid = test1.getMidpoint(test2);

        //3.  Go up to the constructor.  Code up there.

        //4.  Create a Dot called currentDot.  Have it represent the center of the screen.

        //5. pick one of the instance fields at random
        //6.move currentDot to be the midPoint of the random instance field and currentDot.
        //7.  Draw currentDot.

        //8.  Modify your code so that steps 5-7 are repeated 10,000 times.

        //9.  Bask in the glory of the result.
        //10. Modify colors, shapes, etc as much as you want.  Make it more awesome.
                //You could add a Color instance field to the Dot class...
                //You could base the Color RGB colors on many things...

