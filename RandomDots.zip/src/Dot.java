import java.awt.*;

/**
 * Created by michael_hopps on 10/5/17.
 */
public class Dot {

    private int x, y;

    //Constructor that takes in values for x and y
    // and assigns them to instance fields.



    public Dot (int x, int y){
        this.x=x;
        this.y=y ;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void draw(Graphics2D g2) {
        g2.drawOval(x,y,1,1);
    }

    public Dot getMidpoint(Dot other){

        int x1 = getX();
        int y1 = getY();

        int x2 = other.getX();
        int y2 = other.getY();

        int midx = (x1+x2)/3;
        int midy = (y1+y2)/3;

        Dot mid = new Dot(midx, midy);
        return mid;

    }
    //Methods!
    //1.  getX() -> returns x
    //2.  getY() -> returns y

    //3.  draw(Graphics2D g2) -> draws this dot (drawOval with w,h = 1,1)

    //4.  public Dot getMidpoint(Dot other){
    //      returns the Dot that is the midpoint of THIS Dot
    //      and the parameter other Dot.
    //      recall the midpoint formula: ( (x1+x2)/2, (y1+y2)/2 )
    //} int midX = (X+ other.getX())/2

}
