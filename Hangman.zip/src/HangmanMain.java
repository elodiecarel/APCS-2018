import java.util.Scanner;
import javax.swing.*;
import java.awt.*;


/**
 * Created by michael_hopps on 11/6/17.
 */
public class HangmanMain {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Hangman Memes");

        int width = 600;
        int height = 850;
        frame.setPreferredSize(new Dimension(width, height+24));
//
//
        HangmanPanel panel = new HangmanPanel();

        panel.setFocusable(true);
        panel.grabFocus();

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);

       String[] str = new String[37];

        boolean willContinue = true;


do {

    HangmanChecker hangtest = new HangmanChecker("test", panel);

    Scanner input = new Scanner(System.in);
    System.out.println("Welcome to Hangman. Type to start playing!");

    hangtest.getWords();

    while (hangtest.getGuessesLeft() > 0) {
        hangtest.printStatus();
        String guess = input.next();
        hangtest.checkGuess(guess);
        if(hangtest.didWin())
            break;
    }


    panel.setShowKermitMemes(true);
    panel.repaint();
    Scanner keepPlaying = new Scanner(System.in);
    System.out.println("\nWant to play again? \n Type \"Y\" to keep playing \n Type \"N\" to stop");

    String keepGoing = keepPlaying.next();
    panel.setShowKermitMemes(false);
    panel.setMemes(null);
    panel.repaint();

    if(keepGoing.contentEquals("N")){
        willContinue = false;
    }
    else
        willContinue = true;

}
while (willContinue == true);

    }
}
