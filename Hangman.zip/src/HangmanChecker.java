import javax.swing.*;
import java.awt.*;

/**
 * Created by elodie carel on 11/6/17.
 */
public class HangmanChecker {

    private String secretWord;
    private String display;
    private int guessesLeft;
    private HangmanPanel panel;

    private Memes winnerMemes;
    private Memes loserMemes;

    public HangmanChecker(String secretWord, HangmanPanel panel) {

        this.secretWord = secretWord;
        this.display = "";

        for (int i = 0; i < secretWord.length(); i++) {
            display = display + "*";
        }

        guessesLeft = 10;

        winnerMemes = new Memes("boi-he-did-it-5017004.png");
        this.panel = panel;

        loserMemes = new Memes("Failure.jpg");
    }

    public void checkGuess(String guess) {

        if (secretWord.contains(guess)) {
            System.out.println("Yup, you got it!");
            replaceAll(guess);
        }

        else if (guessesLeft > 0) {
            guessesLeft = guessesLeft - 1;
        }

        else System.out.println("Game over");
    }


    public void replaceAll(String guess) {

        String newDisplay = "";

        for (int i = 0; i < secretWord.length(); i++) {

            if (secretWord.substring(i, i + 1).equals(guess)) {
                newDisplay += guess;
            } else {
                newDisplay += display.substring(i, i + 1);
            }
        }
        display = newDisplay;
    }


    public void printStatus() {
        System.out.println(display);
        System.out.println("You have " + guessesLeft + " guesses left!\n ");
    }

    public int getGuessesLeft() {
        return guessesLeft;
    }

    public boolean didWin() {
        if (display.equals(secretWord)) {
            System.out.println("You're a winner!\n");
            panel.setMemes(winnerMemes);
            panel.repaint();
            return true;

        } else if (guessesLeft > 0) {
            System.out.println("Keep going!");
            return false;

        } else {
            System.out.println("\nYou're a loser");
            panel.setMemes(loserMemes);
            panel.repaint();
            return false;
        }
    }

    public void getWords(){
        int a;
        String[] sArray = {"potato", "kitten", "christmas", "compsci"};

        a = (int)(Math.random()*(sArray.length));

        secretWord = sArray[a];
        display = "";
        for (int i = 0; i < secretWord.length(); i++) {
            display = display + "*";
        }
    }
}

