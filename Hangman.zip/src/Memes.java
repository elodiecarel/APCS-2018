import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Created by student on 11/9/17.
 */
public class Memes {

    public BufferedImage image;

    public Memes(String imageName){


        try{
            image = ImageIO.read(this.getClass().getResourceAsStream(imageName));

        }
        catch (IOException ex) {
            throw new RuntimeException("File not found");
        }
    }
}
