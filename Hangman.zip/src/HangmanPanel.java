/**
 * Created by student on 11/9/17.
 */

import java.awt.*;
import java.time.Year;
import javax.swing.JPanel;

public class HangmanPanel extends JPanel{

    private Memes memes;
    private Memes kermitMemes;
    private boolean showKermitMemes;

    public HangmanPanel() {
        kermitMemes = new Memes("Kermit.png");
    }

    public void setShowKermitMemes(boolean show) {
        showKermitMemes = show;
    }

    public void setMemes(Memes memes) {
        this.memes = memes;
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        if (memes != null) {
            g2.drawImage(memes.image, 0, 0, this);
        }

        if (showKermitMemes) {
            g2.drawImage(kermitMemes.image, 0, 475, this);
        }

    }
}


